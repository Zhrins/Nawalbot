/*
* Nama fitur : Speech Writer
* Type : Plugin Esm
* Sumber : https://whatsapp.com/channel/0029Vb6chx1LI8YVtJJJ9a0Y
* Author : ZenzzXD
* Sumber skrep : Gienetic https://whatsapp.com/channel/0029Vb5EZCjIiRotHCI1213L/457
*/
require('../settings/config');
const axios = require('axios');
const fs = require('fs');

const Base_Api = 'https://www.junia.ai/api/free-tools/generate'

async function juniaRequest(payload) {
  if (!payload || !payload.op) throw new Error('Payload harus ada dan minimal berisi field op')
  try {
    const res = await axios.post(Base_Api, payload, {
      headers: {
        'Content-Type': 'application/json',
        'x-api-client-version': '4',
        'user-agent': 'Mozilla/5.0 (Linux; Android 10; Redmi Note 5 Pro Build/QQ3A.200805.001) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.7204.179 Mobile Safari/537.36',
        'x-requested-with': 'com.chromasterZ.vn',
        origin: 'https://www.junia.ai',
        referer: 'https://www.junia.ai/tools/ai-speech-writer',
        accept: '*/*',
      }
    })
    return res.data
  } catch (err) {
    console.error('Junia API Error:', err.response?.data || err.message)
    throw new Error('Layanan Junia sedang error.')
  }
}

function cleanResult(text) {
  if (!text) return text
  return text.replace(/\s?[0-9a-f]{4,}-[0-9a-f]{4,}$/i, '').trim()
}

async function aiSpeechWriter(details) {
  if (!details) throw new Error('Details harus diisi untuk ai-speech-writer')
  const res = await juniaRequest({ details, op: 'ai-speech-writer' })
  return cleanResult(res.result || res)
}

let handler = async (m, { conn, text, reply }) => {
    
   // Path absolut ke registered.json
    const ownerPath = '/home/container/database/registered.json';
    
    let registeredUsers = [];
    
    console.log('Checking registered.json at:', ownerPath);
    
    // Baca file registered.json
    try {
        if (fs.existsSync(ownerPath)) {
            const rawData = fs.readFileSync(ownerPath, 'utf-8');
            registeredUsers = JSON.parse(rawData);
            console.log('Registered users count:', registeredUsers.length);
            console.log('Registered users:', registeredUsers.map(user => user.id));
        } else {
            console.log('registered.json not found at:', ownerPath);
            return reply('❌ File registered.json tidak ditemukan!');
        }
    } catch (error) {
        console.log('Error reading registered.json:', error);
        return reply('❌ Error membaca file registered.json: ' + error.message);
    }

    // Cek apakah sender adalah user terdaftar
    // Karena formatnya array of objects, kita cek property 'id'
    const isRegistered = registeredUsers.some(user => user.id === m.sender);

    console.log('Sender:', m.sender);
    console.log('Is Registered:', isRegistered); 
    
   if (!isRegistered) return reply('❌ Maaf, fitur ini hanya untuk user yang sudah terdaftar!') 
   
   if (!text) return reply('❌ Contoh penggunaan:\n.speechwriter <teks>\n\n*Contoh:*\n.speechwriter pidato tentang pentingnya pendidikan karakter untuk generasi muda')
   
   try {
    await m.reply('⏳ Sedang menulis speech, tunggu sebentar...')
    const speech = await aiSpeechWriter(text)
    
    if (!speech || speech.trim() === '') {
        return reply('❌ Gagal menghasilkan speech. Coba lagi dengan teks yang berbeda.')
    }
    
    // Potong teks jika terlalu panjang untuk WhatsApp
    const maxLength = 4000;
    if (speech.length > maxLength) {
        const part1 = speech.substring(0, maxLength);
        const part2 = speech.substring(maxLength);
        await m.reply(`📝 *Speech Writer Result (Part 1/2):*\n\n${part1}`);
        await m.reply(`📝 *Speech Writer Result (Part 2/2):*\n\n${part2}`);
    } else {
        await m.reply(`📝 *Speech Writer Result:*\n\n${speech}`);
    }
    
  } catch (e) {
    console.error('Speech Writer Error:', e);
    m.reply(`❌ Error: ${e.message}`)
  }
}

handler.help = ['speechwriter <teks>']
handler.tags = ['ai']
handler.command = ['speechwriter', 'speech']

module.exports = handler