const fs = require("fs");
const path = require("path");

const handler = async (m, { reply, text, command }) => {
try {
    // Path absolut ke owner.json
    const ownerPath = '/home/container/database/owner.json';
    let ownerData = [];
    
    console.log('Checking owner.json at:', ownerPath);
    
    // Baca file owner.json
    try {
        if (fs.existsSync(ownerPath)) {
            const rawData = fs.readFileSync(ownerPath, 'utf-8');
            ownerData = JSON.parse(rawData);
            console.log('Owner.json content:', ownerData);
        } else {
            console.log('Owner.json not found at:', ownerPath);
            return reply('File owner.json tidak ditemukan!');
        }
    } catch (error) {
        console.log('Error reading owner.json:', error);
        return reply('Error membaca file owner.json: ' + error.message);
    }

    // Cek apakah sender adalah owner
    const isOwner = Array.isArray(ownerData) 
        ? ownerData.includes(m.sender)
        : ownerData === m.sender;

    console.log('Sender:', m.sender);
    console.log('Is owner:', isOwner);

    if (!isOwner) return reply(mess.owner || 'Hanya owner yang bisa menggunakan command ini!');

    // Validasi input
    if (!text || !m.quoted || !m.quoted.text) 
        return reply(`Reply kode & input nama plugin\n*contoh:* ${command} menu.js dengan reply codenya`);

    if (!text.endsWith(".js")) 
        return reply(`Reply kode & input nama plugin\n*contoh:* ${command} menu.js dengan reply codenya`);

    // Save plugin
    const pluginPath = `./command/${text.trim()}`;
    await fs.writeFileSync(pluginPath, m.quoted.text);
    
    const res = ["saveplugin", "saveplugins", "svp", "sp"]
    const action = res.includes(command) ? "save" : "menambah"
    
    return reply(`Berhasil ${action} plugin *${text}*`)

} catch (err) {
    console.log(err)
    return reply('Terjadi error: ' + err.message)
}
}

handler.command = ["addp2", "addplugin", "addplugins", "saveplugin", "saveplugins", "svp", "sp"]
module.exports = handler