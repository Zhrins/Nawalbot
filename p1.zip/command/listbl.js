const fs = require("fs");
const path = require("path");

const filePath = path.join(process.cwd(), "ADDTIONAL", "whitelist.json");

function getData() {
    if (!fs.existsSync(filePath)) return [];
    return JSON.parse(fs.readFileSync(filePath));
}

const listbl = async (m, { client }) => {
    const data = getData();

    if (data.length === 0) {
        return client.sendMessage(m.chat, {
            text: "📭 Tidak ada group dalam blacklist JPM."
        });
    }

    let teks = `🚫 *DAFTAR BLACKLIST JPM*\n\n`;
    
    // Ambil nama grup untuk setiap ID
    for (let i = 0; i < data.length; i++) {
        try {
            const groupMetadata = await client.groupMetadata(data[i]);
            teks += `${i + 1}. ${groupMetadata.subject} (${data[i]})\n`;
        } catch (error) {
            teks += `${i + 1}. ${data[i]} (Grup tidak ditemukan)\n`;
        }
    }

    await client.sendMessage(m.chat, { text: teks });
};

module.exports = listbl;
module.exports.command = ['listbl', 'listblacklist', 'daftarbl'];
module.exports.tags = ['admin'];