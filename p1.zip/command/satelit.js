module.exports = async (m, { client }) => {
  const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

  const satelit = [
    "Starlink-77", "ISS (International Space Station)", "NASA Recon", "SatKom-1", 
    "MOSSAD-3", "GeoSat-X", "BlackBird v2", "Hubble-Telescope"
  ];
  const lokasi = [
    "Antartika", "Orbit LEO", "Atas wilayah Indonesia", "Samudra Pasifik", 
    "Atas Moskow", "Area 51", "Luar atmosfer", "Atas Afrika Tengah"
  ];
  const status = [
    "📦 Mengunduh paket nuklir...",
    "🔒 Membuka akses kontrol kamera satelit...",
    "🧬 Memindai struktur termal...",
    "🧲 Mengaktifkan mode stealth...",
    "📶 Menurunkan satelit ke ketinggian kritis...",
    "🚀 Mengubah lintasan satelit..."
  ];

  let target = satelit[Math.floor(Math.random() * satelit.length)];
  let lokasiNow = lokasi[Math.floor(Math.random() * lokasi.length)];

  await client.sendMessage(m.chat, { text: `🔍 Mendeteksi satelit *${target}*...` }, { quoted: m });
  await delay(1500);
  await client.sendMessage(m.chat, { text: `📡 Menghubungkan ke antena penguat sinyal...` }, { quoted: m });
  await delay(1500);
  await client.sendMessage(m.chat, { text: `💻 Bypass firewall orbit...\n🧠 Mem-bypass enkripsi AES-256...` }, { quoted: m });
  await delay(1800);
  await client.sendMessage(m.chat, { text: `🛰️ Terhubung ke *${target}*\n📶 Signal Locked: ✅\n💾 Mengambil data orbit...` }, { quoted: m });
  await delay(2000);

  for (let i = 0; i < 4; i++) {
    await delay(1500);
    await client.sendMessage(m.chat, { text: status[Math.floor(Math.random() * status.length)] }, { quoted: m });
  }

  await delay(1800);
  await client.sendMessage(m.chat, {
    text: `✅ *Sukses mengakses satelit ${target}*\n\n📍 Lokasi: ${lokasiNow}\n📡 Status: Aktif\n🕐 Waktu Server: ${new Date().toLocaleTimeString()}\n\n⚠️ Catatan: Ini hanya simulasi untuk hiburan.`,
  }, { quoted: m });
};

module.exports.command = ['hacksatelit', 'gesersatelit'];
module.exports.tags = ['fun'];
