const axios = require('axios');

const handler = async (m, { reply, text, command }) => {
  try {
    if (!text) {
      return reply(`Masukan nama nabi\nContoh: kisahnabi adam`);
    }
    
    let url = `https://raw.githubusercontent.com/ZeroChanBot/Api-Freee/a9da6483809a1fbf164cdf1dfbfc6a17f2814577/data/kisahNabi/${text}.json`;
    let response = await axios.get(url);
    let kisah = response.data;
    
    if (!kisah) {
      return reply("*Not Found*\n*📮 ᴛɪᴘs :* coba jangan gunakan huruf capital");
    }
    
    let hasil = `_*👳 Nabi :*_ ${kisah.name}
_*📅 Tanggal Lahir :*_ ${kisah.thn_kelahiran}
_*📍 Tempat Lahir :*_ ${kisah.tmp}
_*📊 Usia :*_ ${kisah.usia}

*— — — — — — — [ K I S A H ] — — — — — — —*

${kisah.description}`;
    
    reply(`${hasil}`);
  } catch (err) {
    console.log(err);
    if (err.response && err.response.status === 404) {
      return reply("*Not Found*\n*📮 ᴛɪᴘs :* coba jangan gunakan huruf capital");
    }
    return reply('Terjadi error: ' + err.message);
  }
}

handler.command = ["kisahnabi"]
module.exports = handler