const fs = require("fs");
const path = require("path");

const filePath = path.join(process.cwd(), "ADDTIONAL", "whitelist.json");

function getData() {
    if (!fs.existsSync(filePath)) return [];
    return JSON.parse(fs.readFileSync(filePath));
}

function saveData(data) {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

const delbl = async (m, { client, message }) => {
    const from = m.chat;

    if (!from || !from.endsWith("@g.us")) {
        return client.sendMessage(from, {
            text: "❌ Perintah ini hanya bisa digunakan di dalam group."
        });
    }

    let data = getData();

    if (!data.includes(from)) {
        return client.sendMessage(from, {
            text: "⚠️ Group ini tidak ada di blacklist JPM."
        });
    }

    data = data.filter(id => id !== from);
    saveData(data);

    await client.sendMessage(from, {
        text: "✅ Group ini berhasil dihapus dari blacklist JPM.\n\nGroup ini akan menerima JPM kembali."
    });
};

module.exports = delbl;
module.exports.command = ['delbl', 'delblacklist'];
module.exports.tags = ['admin'];