const cekid = async (m, { client, args }) => {
    const sender = m.chat;
    const command = m.text;

    if (!args[0]) {
        return client.sendMessage(sender, {
            text: "❗ Contoh penggunaan:\n\n" +
                  ".cekid https://chat.whatsapp.com/xxxxx\n" +
                  ".cekid https://whatsapp.com/channel/xxxxx"
        });
    }

    const input = args[0].trim();

    try {
        // ===== CEK CHANNEL =====
        if (input.includes("whatsapp.com/channel/")) {
            const invite = input.split("channel/")[1]?.split("?")[0];
            if (!invite) {
                return client.sendMessage(sender, {
                    text: "❗ Link channel tidak valid."
                });
            }

            const data = await client.newsletterMetadata("invite", invite);
            const meta = data.thread_metadata || {};

            return client.sendMessage(sender, {
                text: `乂 *CHANNEL DITEMUKAN*\n\n` +
                      `◦ ID Channel:\n${data.id}\n\n` +
                      `◦ Nama: ${meta.name?.text || "-"}\n` +
                      `◦ Subscribers: ${meta.subscribers_count || "0"}\n` +
                      `◦ Status: ${data.state?.type || "-"}\n` +
                      `◦ Verifikasi: ${meta.verification || "UNVERIFIED"}\n\n` +
                      `◦ Deskripsi:\n${meta.description?.text || "-"}`
            });
        }

        // ===== CEK GROUP =====
        if (input.includes("chat.whatsapp.com/")) {
            const invite = input.split("chat.whatsapp.com/")[1]?.split("?")[0];
            if (!invite) {
                return client.sendMessage(sender, {
                    text: "❗ Link grup tidak valid."
                });
            }

            const data = await client.groupGetInviteInfo(invite);
            
            // Hitung jumlah admin
            const adminCount = data.participants?.filter(p => p.admin).length || 0;

            return client.sendMessage(sender, {
                text: `乂 *GROUP DITEMUKAN*\n\n` +
                      `◦ ID Group:\n${data.id}\n\n` +
                      `◦ Nama: ${data.subject}\n` +
                      `◦ Member: ${data.size}\n` +
                      `◦ Admin: ${adminCount}\n` +
                      `◦ Deskripsi:\n${data.desc || "-"}`
            });
        }

        return client.sendMessage(sender, {
            text: "❗ Link tidak dikenali. Gunakan link Group atau Channel WhatsApp."
        });

    } catch (err) {
        console.error(err);
        return client.sendMessage(sender, {
            text: "❗ Gagal mengambil data. Pastikan link valid & bot tidak diblokir."
        });
    }
};

module.exports = cekid;
module.exports.command = ['cekid', 'cekgrup', 'cekinvite'];
module.exports.tags = ['tools'];