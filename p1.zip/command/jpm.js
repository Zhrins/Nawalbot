const fs = require("fs");
const path = require("path");
const { isOwner } = require("../lib/ownerCheck.js");

// Path untuk blacklist
const blacklistPath = path.join(process.cwd(), "ADDTIONAL", "whitelist.json");

// Fungsi untuk membaca blacklist
function readBlacklist() {
    try {
        const dirPath = path.join(process.cwd(), "ADDTIONAL");
        const whitelistPath = path.join(dirPath, "whitelist.json");

        if (!fs.existsSync(dirPath)) {
            fs.mkdirSync(dirPath, { recursive: true });
        }

        if (!fs.existsSync(whitelistPath)) {
            fs.writeFileSync(whitelistPath, "[]", "utf8");
        }

        const rawData = fs.readFileSync(whitelistPath, "utf8");
        const blacklist = JSON.parse(rawData);
        return Array.isArray(blacklist) ? blacklist : [];
    } catch (error) {
        console.error("❌ Gagal membaca blacklist:", error);
        return [];
    }
}

// Fungsi untuk download media
async function downloadMedia(client, quoted) {
    try {
        const tmpDir = path.join(process.cwd(), "tmp");
        if (!fs.existsSync(tmpDir)) {
            fs.mkdirSync(tmpDir, { recursive: true });
        }
        
        const filename = `jpm_${Date.now()}.jpeg`;
        const filePath = path.join(tmpDir, filename);
        
        const buffer = await client.downloadMediaMessage(quoted);
        fs.writeFileSync(filePath, buffer);
        
        return filePath;
    } catch (error) {
        console.error("Gagal download media:", error);
        return null;
    }
}

// Fungsi sleep
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

const jpm = async (m, { client, args }) => {
    const sender = m.chat;
    const senderNumber = m.key?.remoteJid || m.chat;
    const text = m.text || args.join(' ');
    const quoted = m.quoted;
    const mimeType = quoted?.message?.imageMessage ? 'image' : null;
    
    // PENGECEKAN OWNER
    if (!isOwner(senderNumber)) {
        return client.sendMessage(sender, { 
            text: "❌ Perintah ini hanya untuk owner bot."
        });
    }
    
    let mediaPath = null;

    // Cek apakah ada gambar yang dikutip
    if (quoted && mimeType === 'image') {
        try {
            mediaPath = await downloadMedia(client, quoted);
            if (!mediaPath) {
                return client.sendMessage(sender, { 
                    text: "❌ Gagal mengunduh gambar." 
                });
            }
        } catch (error) {
            console.error("Error download media:", error);
            return client.sendMessage(sender, { 
                text: "❌ Gagal memproses gambar." 
            });
        }
    }

    // Validasi teks
    if (!text && !mediaPath) {
        return client.sendMessage(sender, {
            text: `*Contoh penggunaan:*\n.jpm pesan yang ingin dikirim\n\nAtau dengan gambar:\n.jpm pesan (dengan mengutip gambar)`
        });
    }

    // Ambil semua grup
    const allGroups = await client.groupFetchAllParticipating();
    const groupIds = Object.keys(allGroups);
    
    if (groupIds.length === 0) {
        return client.sendMessage(sender, {
            text: "❌ Bot tidak terdaftar di grup manapun."
        });
    }

    // Baca blacklist
    const blacklist = readBlacklist();
    const targetGroups = blacklist.length > 0 
        ? groupIds.filter(id => !blacklist.includes(id))
        : groupIds;

    if (targetGroups.length === 0) {
        return client.sendMessage(sender, {
            text: "❌ Semua grup berada dalam blacklist."
        });
    }

    await client.sendMessage(sender, {
        text: `📢 Mengirim pesan ke *${targetGroups.length}* grup...\n⚠️ Mohon tunggu.`
    });

    let successCount = 0;
    let failCount = 0;

    // Siapkan pesan dengan tanda khusus [JPM] di awal
    // Tanda ini akan digunakan untuk filter agar pesan JPM tidak diproses sebagai command
    const messageText = `[]${text}`;
    
    const messageContent = mediaPath
        ? { image: fs.readFileSync(mediaPath), caption: messageText }
        : { text: messageText };

    // Kirim ke setiap grup
    for (let i = 0; i < targetGroups.length; i++) {
        const groupId = targetGroups[i];
        const groupName = allGroups[groupId]?.subject || groupId;
        
        if (global.stopjpm) {
            delete global.stopjpm;
            await client.sendMessage(sender, {
                text: `⚠️ Proses dihentikan.\n✅ ${successCount} grup\n❌ ${failCount} grup`
            });
            break;
        }

        try {
            await Promise.race([
                client.sendMessage(groupId, messageContent),
                new Promise((_, reject) => 
                    setTimeout(() => reject(new Error('Timeout')), 10000)
                )
            ]);
            successCount++;
            console.log(`✅ [${successCount}/${targetGroups.length}] ${groupName}`);
        } catch (error) {
            failCount++;
            console.error(`❌ ${groupName}:`, error.message);
        }

        await sleep(global.JedaJpm || 3000);
    }

    if (mediaPath && fs.existsSync(mediaPath)) {
        fs.unlinkSync(mediaPath);
    }

    await client.sendMessage(sender, {
        text: `✅ Selesai!\n✅ ${successCount} grup\n❌ ${failCount} grup\n🚫 Blacklist: ${blacklist.length} grup`
    });
};

module.exports = jpm;
module.exports.command = ['jpmv1', 'jasher', 'jaser', 'geserjpm'];
module.exports.tags = ['admin'];