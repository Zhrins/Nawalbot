const fs = require("fs");
const path = require("path");
const { isOwner } = require("../lib/ownerCheck.js");

const filePath = path.join(process.cwd(), "ADDTIONAL", "whitelist.json");

function getData() {
    try {
        if (!fs.existsSync(filePath)) {
            const dirPath = path.dirname(filePath);
            if (!fs.existsSync(dirPath)) {
                fs.mkdirSync(dirPath, { recursive: true });
            }
            fs.writeFileSync(filePath, "[]");
            return [];
        }
        return JSON.parse(fs.readFileSync(filePath));
    } catch (error) {
        console.error("Gagal membaca data:", error);
        return [];
    }
}

function saveData(data) {
    try {
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
        return true;
    } catch (error) {
        console.error("Gagal menyimpan data:", error);
        return false;
    }
}

function isValidGroupId(id) {
    return id && typeof id === 'string' && id.endsWith("@g.us") && id.includes("-");
}

const addblgc = async (m, { client, args }) => {
    const sender = m.chat;
    const senderNumber = m.key?.remoteJid || m.chat;
    
    // Cek apakah pengguna adalah owner menggunakan fungsi isOwner
    if (!isOwner(senderNumber)) {
        return client.sendMessage(sender, { 
            text: "❌ Perintah ini hanya untuk owner bot.\n\n" +
                  "Jika Anda adalah owner, pastikan nomor Anda sudah terdaftar di file owner.json\n" +
                  "Folder: ADDTIONAL/owner.json"
        });
    }

    // Validasi argumen
    if (!args || args.length === 0 || !args[0]) {
        return client.sendMessage(sender, {
            text: "❗ *Cara Penggunaan:*\n\n" +
                  "`.addblgc <ID Grup>`\n\n" +
                  "*Contoh:*\n" +
                  "`.addblgc 1234567890-123456@g.us`\n\n" +
                  "📌 *Cara mendapatkan ID Grup:*\n" +
                  "1. Kirim perintah `.listgc` untuk melihat daftar grup\n" +
                  "2. Atau gunakan perintah `.cekid` pada link grup\n\n" +
                  "⚠️ *Catatan:*\n" +
                  "• ID grup harus berakhiran @g.us\n" +
                  "• Grup yang ditambahkan ke blacklist tidak akan menerima pesan JPM"
        });
    }

    const groupId = args[0].trim();
    
    // Validasi format ID grup
    if (!isValidGroupId(groupId)) {
        return client.sendMessage(sender, {
            text: "❌ *ID Grup tidak valid!*\n\n" +
                  "Format ID grup yang benar: `xxxxxxxxxx-xxxxxx@g.us`\n\n" +
                  "Contoh: `1234567890-123456@g.us`\n\n" +
                  "📌 Gunakan perintah `.listgc` untuk melihat daftar ID grup."
        });
    }

    // Cek apakah grup ada dan bot masih menjadi member
    try {
        const groupMetadata = await client.groupMetadata(groupId);
        
        if (!groupMetadata) {
            return client.sendMessage(sender, {
                text: "❌ Grup tidak ditemukan atau bot sudah tidak menjadi member di grup tersebut."
            });
        }
        
        const groupName = groupMetadata.subject;
        
        let data = getData();
        
        // Cek apakah grup sudah ada di blacklist
        if (data.includes(groupId)) {
            return client.sendMessage(sender, {
                text: `⚠️ *Grup sudah ada di blacklist!*\n\n` +
                      `📛 Nama Grup: ${groupName}\n` +
                      `🆔 ID Grup: ${groupId}\n\n` +
                      `Grup ini sudah tidak akan menerima pesan JPM.`
            });
        }
        
        // Tambahkan ke blacklist
        data.push(groupId);
        const saved = saveData(data);
        
        if (!saved) {
            return client.sendMessage(sender, {
                text: "❌ Gagal menyimpan data. Silakan coba lagi."
            });
        }
        
        // Kirim pesan sukses
        await client.sendMessage(sender, {
            text: `✅ *Berhasil menambahkan grup ke blacklist!*\n\n` +
                  `📛 *Nama Grup:* ${groupName}\n` +
                  `🆔 *ID Grup:* ${groupId}\n` +
                  `📊 *Total Blacklist:* ${data.length} grup\n\n` +
                  `🚫 Grup ini tidak akan menerima pesan JPM lagi.\n\n` +
                  `📌 Untuk menghapus dari blacklist, gunakan:\n` +
                  `\`.delblgc ${groupId}\``
        });
        
    } catch (error) {
        console.error("Error saat mengecek grup:", error);
        
        if (error.message?.includes("not-found") || error.message?.includes("401") || error.message?.includes("404")) {
            return client.sendMessage(sender, {
                text: "❌ *Grup tidak ditemukan!*\n\n" +
                      "Pastikan:\n" +
                      "1. ID grup yang dimasukkan benar\n" +
                      "2. Bot masih menjadi member di grup tersebut\n" +
                      "3. ID grup berakhiran @g.us\n\n" +
                      "📌 Gunakan perintah `.listgc` untuk melihat daftar grup yang bot ikuti."
            });
        }
        
        return client.sendMessage(sender, {
            text: `❌ *Gagal menambahkan grup ke blacklist!*\n\n` +
                  `Error: ${error.message || "Terjadi kesalahan"}\n\n` +
                  `Pastikan ID grup valid dan bot masih member di grup tersebut.`
        });
    }
};

module.exports = addblgc;
module.exports.command = ['addblgc', 'addblacklistgc'];
module.exports.tags = ['admin'];