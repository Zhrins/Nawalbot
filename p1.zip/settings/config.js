/*
╭────────────────────────────────────────
│ GitHub   : https://github.com/r-serex
│ YouTube  : https://youtube.com/@zxruzx
│ WhatsApp : https://wa.me/6288980698613
│ Telegram : https://rujekaciw.t.me
╰─────────────────────────────────────────
*/

const fs = require('fs')

//~~~~~~~~~ Setting Owner ~~~~~~~~~~//
global.namabot = "NwalHost V1"
global.creator = "NwalHost"
global.linkOwner = "https://wa.me/6295326339223"
global.linkBot = "62882000478539"
global.owner = "62895326339223"
global.namaowner = "NwalHost"

//~~~~~~~~~ Setting Channel ~~~~~~~~~~//
global.apiweb = "https://api.zenzxz.my.id"
global.namach = "27 | Nwalzzz"
global.linkch = "https://whatsapp.com/channel/0029Vb6szsQBKfhz7MxoLq3O"
global.idch = "120363420347390881@newsletter"

//~~~~~~~~~ Setting Packname ~~~~~~~~~~//
global.packname = "WhatsApp Bot 2025"
global.author = "https://wa.me/62882000478539"

//~~~~~~~~~ Setting Status ~~~~~~~~~~//
global.status = true
global.welcome = false

//~~~~~~~~~ Setting Apikey ~~~~~~~~~~//
global.KEY = "sk_be784c0393db28578dcb9ae06905ac57dec14ed457f16833"
global.IDVOICE = "GET ON elevenlabs.io"

global.pairing = "KONTOLLU"

//~~~~~~~~~ Setting Message ~~~~~~~~~~//
global.mess = {
    owner: "Fitur ini khusus untuk NwalHost", 
    premium: "Fitur Khusus Premium",
    member: "Fitur Khusus Member",
    group: "Fitur ini untuk dalam grup!", 
    private: "Fitur ini untuk dalam private chat!",
    user: "Anda Belum Daftar Dulu Yukk pake Perintah .regis nama contoh : .regis Nwalhost",
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
