/*
╭────────────────────────────────────────
│ GitHub   : https://github.com/r-serex
│ YouTube  : https://youtube.com/@zxruzx
│ WhatsApp : https://wa.me/6288980698613
│ Telegram : https://rujekaciw.t.me
╰─────────────────────────────────────────
*/

require('./settings/config');
const fs = require('fs');
const crypto = require('crypto');
const axios = require('axios');
const chalk = require("chalk");
const jimp = require("jimp")
const util = require("util");
const fetch = require( "node-fetch")
const yts = require('yt-search');
const moment = require("moment-timezone");
const path = require("path")
const os = require('os');
const {
    spawn,
    exec,
    execSync
} = require('child_process');

const {
    default:
    baileys,
    getContentType,
} = require("@whiskeysockets/baileys");

module.exports = client = async (client, m, chatUpdate, store, Nwal) => {
    try {
        const body = (
            m.mtype === "conversation" ? m.message.conversation :
                m.mtype === "imageMessage" ? m.message.imageMessage.caption :
                    m.mtype === "videoMessage" ? m.message.videoMessage.caption :
                        m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
                            m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
                                m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
                                    m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
                                        m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
                                            m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
                                                m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : "");

        const sender = m.key.fromMe ? client.user.id.split(":")[0] + "@s.whatsapp.net" || client.user.id
            : m.key.participant || m.key.remoteJid;

        const senderNumber = sender.split('@')[0];
        const budy = (typeof m.text === 'string' ? m.text : '');
        const prefa = ["", "!", ".", ",", "🐤", "🗿"];
        const {
  getRegisteredRandomId,
  addRegisteredUser,
  createSerial,
  checkRegisteredUser
} = require("./database/register.js");
        const prefixRegex = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/;
        const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : '.';
        const from = m.key.remoteJid;
        const isGroup = from.endsWith("@g.us");
        const premium = JSON.parse(fs.readFileSync("./database/premium.json"))
        const owner = JSON.parse(fs.readFileSync("./database/owner.json"))
        const user = JSON.parse(fs.readFileSync("./database/registered.json"))
        const isOwner = owner.includes(m.sender)
        const isPremium = premium.includes(m.sender)
        const isRegistered = checkRegisteredUser(m.sender);
        const kontributor = JSON.parse(fs.readFileSync('./start/lib/database/owner.json'));
        const botNumber = await client.decodeJid(client.user.id);
        const Access = [botNumber, ...kontributor, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
        
        async function asepReact() {
      client.sendMessage(from, {
        react: {
          text: "🕑",
          key: m.key
        }
      })
    }

 

        const isCmd = body.startsWith(prefix);
        const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
        const command2 = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
        const args = body.trim().split(/ +/).slice(1);
        const pushname = m.pushName || "No Name";
        const text = q = args.join(" ");
        const quoted = m.quoted ? m.quoted : m;
        const mime = (quoted.msg || quoted).mimetype || '';
        const qmsg = (quoted.msg || quoted);
        const isMedia = /image|video|sticker|audio/.test(mime);
        const isCreator = [botNumber, ...kontributor, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
        const groupMetadata = isGroup ? await client.groupMetadata(m.chat).catch((e) => { }) : "";
        const groupOwner = isGroup ? groupMetadata.owner : "";
        const groupName = m.isGroup ? groupMetadata.subject : "";
        const participants = isGroup ? await groupMetadata.participants : "";
        const groupAdmins = isGroup ? await participants.filter((v) => v.admin !== null).map((v) => v.id) : "";
        const groupMembers = isGroup ? groupMetadata.participants : "";
        const isGroupAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
        const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
        const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
        const isAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
        

        const {
            smsg,
            fetchJson,
            sleep,
            formatSize
        } = require('./start/lib/myfunction');

        const { remini } = require('./start/lib/function/remini');

        const cihuy = fs.readFileSync('./start/lib/media/orderM.png')
        const { fquoted } = require('./start/lib/fquoted')

        if (m.message) {
            console.log('\x1b[30m--------------------\x1b[0m');
            console.log(chalk.bgHex("#8b0000").bold(`📩  - New Message`));
            console.log(
                chalk.bgHex("#4a69bd").black(
                    `▢ Tanggal: ${new Date().toLocaleString()} \n` +
                    `▢ Pesan: ${m.body || m.mtype} \n` +
                    `▢ Pengirim: ${pushname} \n` +
                    `▢ JID: ${senderNumber}`
                )
            );

            if (m.isGroup) {
                console.log(
                    chalk.bgHex("#4a69bd").black(
                        `▢ Grup: ${groupName} \n` +
                        `▢ GroupJid: ${m.chat}`
                    )
                );
            }
            console.log();
        }

        //menghapus statusMention di Group
        if (m.mtype.includes("groupStatusMentionMessage") && m.isGroup) {
            await client.deleteMessage(m.chat, m.key);
        }

        const reaction = async (jidss, emoji) => {
            client.sendMessage(jidss, {
                react: {
                    text: emoji,
                    key: m.key
                }
            })
        };

        async function reply(text) {
            client.sendMessage(m.chat, {
                text: text,
                contextInfo: {
                    mentionedJid: [sender],
                                       
                    externalAdReply: {
                        title: `NwalHost - 2025`,
                        body: "Bot Nwal",
                        thumbnailUrl: "https://img1.pixhost.to/images/8837/642547361_encore.jpg",
                        sourceUrl: global.linkch,
                        renderLargerThumbnail: false,
                    }
                }
            }, { quoted: m })
        }

        const pluginsLoader = async (directory) => {
            let plugins = [];
            const folders = fs.readdirSync(directory);
            folders.forEach(file => {
                const filePath = path.join(directory, file);
                if (filePath.endsWith(".js")) {
                    try {
                        const resolvedPath = require.resolve(filePath);
                        if (require.cache[resolvedPath]) {
                            delete require.cache[resolvedPath];
                        }
                        const plugin = require(filePath);
                        plugins.push(plugin);
                    } catch (error) {
                        console.log(`${filePath}:`, error);
                    }
                }
            });
            return plugins;
        };

        const pluginsDisable = true;
        const plugins = await pluginsLoader(path.resolve(__dirname, "./command"));
        const plug = { client, prefix, command, reply, text, Access, reaction, isGroup: m.isGroup, isPrivate: !m.isGroup, pushname, mime, quoted, sleep, fetchJson };

    for (let plugin of plugins) {
      if (plugin.command.find(e => e == command.toLowerCase())) {
                if (plugin.owner && !Access) {
                    return reply(mess.owner);
                }

                if (plugin.group && !plug.isGroup) {
                    return m.reply(mess.group);
                }

                if (plugin.private && !plug.isPrivate) {
                    return m.reply(mess.private);
                }

                if (typeof plugin !== "function") return;
                await plugin(m, plug);
            }
        }

        if (!pluginsDisable) return;

        switch (command) {

            case "menu": {
    if (!isRegistered) return m.reply(mess.user)
    
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    const formattedUsedMem = formatSize(usedMem);
    const formattedTotalMem = formatSize(totalMem);

    // Path ke gambar thumbnail lokal
    const thumbPath = "./asset/image/thumb2.jpg";
    
    // Quoted location untuk .menu
    const qloc = {
        "key": {
            "participant": '0@s.whatsapp.net',
            "remoteJid": "status@broadcast",
            "fromMe": false,
            "id": "X"
        },
        "message": {
            "locationMessage": {
                "name": '🌐 Bot WhatsApp NwalHost',
                "jpegThumbnail": ''
            }
        }
    };

    let thumbnail;
    try {
        if (fs.existsSync(thumbPath)) {
            thumbnail = fs.readFileSync(thumbPath);
        } else {
            // Fallback jika file tidak ditemukan
            console.log("Thumbnail file not found, using default");
            thumbnail = fs.readFileSync("./asset/image/thumb2.jpg"); // Ganti dengan path default jika ada
        }
    } catch (error) {
        console.log("Error loading thumbnail:", error);
        thumbnail = fs.readFileSync("./asset/image/thumb2.jpg"); // Ganti dengan path default jika ada
    }

    const menuText = `Hi @${m.sender.split('@')[0]}, Selamat Datang Di Bot NwalHost

— Information Bot
▣ Owner : ${global.owner}
▣ Botname : ${global.namabot}
▣ Mode : ${client.public ? 'public' : 'self'}
▣ Creator : ${global.creator}

╭──── ⌜ Navigasi Menu ⌟
  ▣ .allmenu
  📊 Total Fitur: 62
╰─────────────ヌ

*© Nwalhost*`;

    // Fungsi loading untuk .menu
    async function loadingMenu() {
        var nln = [
            `Mohon Menunggu [10%]`,
            `Mohon Menunggu [20%]`,
            `Mohon Menunggu [30%]`,
            `Mohon Menunggu [40%]`,
            `Mohon Menunggu [50%]`,
            `Mohon Menunggu [60%]`,
            `Mohon Menunggu [70%]`,
            `Mohon Menunggu [80%]`,
            `Mohon Menunggu [90%]`,
            `Mohon Menunggu [100%]`,
            `Menu Sedang Otw!`,
        ]
        
        let { key } = await client.sendMessage(m.chat, {
            text: '🔄 Memuat Menu...'
        }, {
            quoted: m
        })
        
        for (let i = 0; i < nln.length; i++) {
            await sleep(300) // Menggunakan sleep function yang sudah ada
            await client.sendMessage(m.chat, {
                text: nln[i],
                edit: key
            }, {
                quoted: m
            });
        }
        
        // Hapus pesan loading terakhir
        await client.sendMessage(m.chat, {
            delete: key
        });
    }

    // Jalankan loading sebelum mengirim menu
    await loadingMenu();

    // Kirim menu setelah loading selesai
    await client.sendMessage(m.chat, {
        image: thumbnail,
        caption: menuText,
        buttons: [ 
            {
                buttonId: 'action',
                buttonText: { displayText: 'ini pesan interactiveMeta' },
                type: 4,
                nativeFlowInfo: {
                    name: 'single_select',
                    paramsJson: JSON.stringify({
                        title: 'Pilih Menu',      
                        sections: [
                            {
                                title: global.packname,
                                highlight_label: "Menu Favorit",
                                rows: [
                                    {
                                        title: 'Downloader',
                                        description: 'Downloader Video/Audio', 
                                        id: `.downloader`
                                    },
                                    {
                                        title: 'All Menu Bot',
                                        description: 'Menunjukan Semua Menu Bot', 
                                        id: `.allmenu9962`
                                    },
                                    {
                                        title: 'Owner',                   
                                        description: 'Khusus Nwalhost',
                                        id: `.owner`
                                    },
                                ]
                            }
                        ]
                    })
                }
            }
        ],
        headerType: 1,
        viewOnce: true,
        contextInfo: {
            mentionedJid: [m.sender],
            
        }
    }, { 
        quoted: qloc // Gunakan quoted location yang sudah dibuat
    });
};
break;
 
case "daftar":
      case "regis":
      case "register":
        {
          if (isRegistered) {
            return reply("Sia Udh Kedaftar Woe Dek Daftar Sbrh kali?");
          }
          const serialUser = createSerial(20);
          const umurUser = q.substring(q.lastIndexOf(".") + 1);
          const nomor = m.sender.split("@")[0];
          const channelJid = "120363398684744234@newsletter"; // JID Channel kamu
          if (umurUser > 1000) {
            return reply(`Maximal umur 1000 untuk melakukan register`);
          }
          if (umurUser < 10) {
            return reply(`Umur kamu belum cukup untuk melakukan registrasi`);
          }
          const mzd = `╭───• *NEW USER* •───
├⎆ *Status:*  _*Success ✓*_
├⎆ *Username:* ${pushname}
├⎆ *Name:* ${umurUser}

⟢ *SN:* ${createSerial(20)}

⟢ 𝗗𝗮𝘁𝗲: ${new Date().toLocaleString()}

_Sekarang anda sudah bisa mengakses bot NwalHost MD.
Ketik .Menu Untuk Mulai Menggunakan Bot_
`;
          const notifLog = `╭───• *NEW USER* •───
├⎆ *Status:*  _*Success ✓*_
├⎆ *Name:* ${pushname}
├⎆ *Umur:* ${umurUser}

⟢ *SN:* ${createSerial(20)}

⟢ 𝗗𝗮𝘁𝗲: ${new Date().toLocaleString()}

_Sekarang anda sudah bisa mengakses bot NwalHost MD_
`;
          veri = m.sender;
          addRegisteredUser(m.sender, pushname, umurUser, serialUser);
          let ppuser;
          try {
            ppuser = await client.profilePictureUrl(m.sender, "image");
          } catch {
            ppuser = "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460960720.png?q=60";
          }

          // Kirim ke user
          client.sendMessage(m.chat, {
            text: mzd,
            contextInfo: {
              isForwarded: true,
              mentionedJid: [m.sender],
              forwardedNewsletterMessageInfo: {
                newsletterJid: "120363420347390881@newsletter",
                newsletterName: `27 | NwalZzz`
              },
              externalAdReply: {
                title: `Register succes ✓`,
                body: `© NwalHost - MD`,
                thumbnailUrl: "https://img1.pixhost.to/images/8837/642547361_encore.jpg",
                sourceUrl: "https://whatsapp.com/channel/0029Vb6szsQBKfhz7MxoLq3O",
                mediaType: 1,
                renderLargerThumbnail: true
              }
            }
          });

          // Kirim ke channel
          client.sendMessage(channelJid, {
            text: notifLog,
            contextInfo: {
              mentionedJid: [m.sender],
              externalAdReply: {
                title: "System Notification",
                body: "Notification Register",
                thumbnailUrl: "https://img1.pixhost.to/images/8837/642547361_encore.jpg",
                sourceUrl: "https://whatsapp.com/channel/0029Vb6szsQBKfhz7MxoLq3O",
                mediaType: 1,
                renderLargerThumbnail: true
              }
            }
          });
        }
        break;                
              
        case "listbkp":
        {
          if (!isOwner) {
            return reply("👋🏻 Halo kak, Maaf, Kamu blum terdaftar di database nih, Daftar dulu yuu,\n=\n╭─ •  「 `CARA DAFTAR` 」\n> ⎙ *Caranya:* .daftar nama. umur\n> ⎙ *Contohnya:* .daftar Tradz. 20\n> ⎙ *Daftar By:* @Nwal\n╰───────────────");
          }
          reply("ada 20 bkp ketik contoh : bkp1");
        }
        break;
      case "bkp1":
        {
        if (!isOwner) return m.reply(mess.owner) 
          reply("https://videy.co/v?id=yUI9qHxy1");
        }
        break;
      case "bkp2":
        {
            if (!isOwner) return m.reply(mess.owner)
          reply("https://videy.co/v?id=taEdfX521");
        }
        break;
      case "bkp3":
        {
            if (!isOwner) return m.reply(mess.owner)
          reply("https://videy.co/v?id=IZ2dEEPR1");
        }
        break;
      case "bkp4":
        {
            if (!isOwner) return m.reply(mess.owner)
          reply("https://videy.co/v?id=cFmHXLnR1");
        }
        break;
      case "bkp5":
        {
            if (!isOwner) return m.reply(mess.owner)
          reply("https://videy.co/v?id=VkhX0rIY1");
        }
        break;
      case "bkp6":
        {
            if (!isOwner) return m.reply(mess.owner)
          reply("https://videy.co/v?id=HbciV3Ng1");
        }
        break;
      case "bkp7":
        {
            if (!isOwner) return m.reply(mess.owner)
          `${global.thumbnail}`;
          "https://videy.co/v?id=iDZaNE341";
        }
        break;
      case "bkp8":
        {
            if (!isOwner) return m.reply(mess.owner)
          reply("https://videy.co/v?id=99FZhvO21");
        }
        break;
      case "bkp9":
        {
            if (!isOwner) return m.reply(mess.owner)
          reply("https://videy.co/v?id=5JeZNWaH1");
        }
        break;
      case "bkp10":
        {
            if (!isOwner) return m.reply(mess.owner)
          reply("https://videy.co/v?id=KTw1lWWa1");
        }
        break;
      case "bkp11":
        {
            if (!isOwner) return m.reply(mess.owner)
          reply("https://videy.co/v?id=UdqYuonc1");
        }
        break;
      case "bkp12":
        {
            if (!isOwner) return m.reply(mess.owner)
          reply("https://videy.co/v?id=vApGwZAC1");
        }
        break;
      case "bkp13":
        {
            if (!isOwner) return m.reply(mess.owner)
          reply("https://videy.co/v?id=ji0jr2f71");
        }
        break;
      case "bkp14":
        {
            if (!isOwner) return m.reply(mess.owner)
          reply("https://videy.co/v?id=kxx94sEr1");
        }
        break;
      case "bkp15":
        {
            if (!isOwner) return m.reply(mess.owner)
          reply("https://videy.co/v?id=jRlBDROc1");
        }
        break;
      case "bkp16":
        {
            if (!isOwner) return m.reply(mess.owner)
          reply("https://videy.co/v?id=LevNyK2x1");
        }
        break;
      case "bkp17":
        {
            if (!isOwner) return m.reply(mess.owner)
          reply("https://videy.co/v?id=a1Uim8Ey");
        }
        break;
      case "bkp18":
        {
            if (!isOwner) return m.reply(mess.owner)
          reply("https://videyvideo.short.gy/Cwdcj1");
        }
        break;
      case "bkp19":
        {
            if (!isOwner) return m.reply(mess.owner)
          reply("https://videy.co/v?id=bliIEHfL1");
        }
        break;
      case "bkp20":
        {
            if (!isOwner) return m.reply(mess.owner)
          reply("https://videy.co/v?id=Yep64SD61");
        }
        break;        
               
          case "spamngl":
        {
          if (!isOwner) {
            return reply(mess.prem);
          }
          if (!text.split("|")[0] || !text.split("|")[1] || !text.split("|")[2]) {
            return reply("Tulis usernamena, pesan, dan jumlah spam!\nContoh: .nglspam Dinz|haloo|5");
          }
          async function sendSpamMessage(username, message, spamCount) {
            let counter = 0;
            while (counter < spamCount) {
              try {
                const date = new Date();
                const minutes = date.getMinutes();
                const hours = date.getHours();
                const FormattedDate = `${hours}:${minutes}`;
                const deviceId = crypto.randomBytes(21).toString("hex");
                const url = "https://ngl.link/api/submit";
                const headers = {
                  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/109.0",
                  Accept: "*/*",
                  "Accept-Language": "en-US,en;q=0.5",
                  "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                  "X-Requested-With": "XMLHttpRequest",
                  "Sec-Fetch-Dest": "empty",
                  "Sec-Fetch-Mode": "cors",
                  "Sec-Fetch-Site": "same-origin",
                  Referer: `https://ngl.link/${username}`,
                  Origin: "https://ngl.link"
                };
                const body = `username=${username}&question=${message}&deviceId=${deviceId}&gameSlug=&referrer=`;
                const response = await fetch(url, {
                  method: "POST",
                  headers,
                  body,
                  mode: "cors",
                  credentials: "include"
                });
                if (response.status !== 200) {
                  console.log(`[${FormattedDate}] [Err] Ratelimited`);
                  await new Promise(resolve => setTimeout(resolve, 25000));
                } else {
                  counter++;
                  console.log(`[${FormattedDate}] [Msg] Sent: ${counter}`);
                }
              } catch (error) {
               
                   console.error(`[${FormattedDate}]
[Err] ${error}`);
                await new Promise(resolve => setTimeout(resolve, 5000));
              }
            }
          }
          ;
          const [username, message, count] = text.split("|");
          const spamCount = parseInt(count, 10);
          if (isNaN(spamCount) || spamCount <= 0) {
            return reply("Jumlah spam harus berupa angka positif!");
          }
          try {
            await sendSpamMessage(username, message, spamCount);
            reply(`Sukses Spam Pesan  ${spamCount} ke ${username} 
By @${m.sender.split('@')[0]}`);
          } catch (e) {
            console.error(e); // Menambahkan logging error untuk debug
            return reply("Fitur error, coba lagi nanti.");
          }
        }
        break;      
                
case "reactch":
case "rch": {
    if (!isOwner) return m.reply(mess.owner);
    if (!text) return m.reply("Contoh:\n.reactch https://whatsapp.com/channel/xxx/123 ❤️zion\n.reactch https://whatsapp.com/channel/xxx/123 ❤️zion|5");

    const hurufGaya = {
        a: '🅐', b: '🅑', c: '🅒', d: '🅓', e: '🅔', f: '🅕', g: '🅖',
        h: '🅗', i: '🅘', j: '🅙', k: '🅚', l: '🅛', m: '🅜', n: '🅝',
        o: '🅞', p: '🅟', q: '🅠', r: '🅡', s: '🅢', t: '🅣', u: '🅤',
        v: '🅥', w: '🅦', x: '🅧', y: '🅨', z: '🅩',
        '0': '⓿', '1': '➊', '2': '➋', '3': '➌', '4': '➍',
        '5': '➎', '6': '➏', '7': '➐', '8': '➑', '9': '➒'
    };

    const [mainText, offsetStr] = text.split('|');
    const argsa = mainText.trim().split(" ");
    const link = argsa[0];

    if (!link.includes("https://whatsapp.com/channel/")) {
        return m.reply("Link tidak valid!\nContoh: .reactch https://whatsapp.com/channel/xxx/idpesan ❤️biyu|3");
    }

    const channelId = link.split('/')[4];
    const rawMessageId = parseInt(link.split('/')[5]);
    if (!channelId || isNaN(rawMessageId)) return m.reply("Link tidak lengkap!");
    const offset = parseInt(offsetStr?.trim()) || 1;
    const teksNormal = argsa.slice(1).join(' ');
    const teksTanpaLink = teksNormal.replace(link, '').trim();
    if (!teksTanpaLink) return m.reply("Masukkan teks/emoji untuk direaksikan.");
    const emoji = teksTanpaLink.toLowerCase().split('').map(c => {
        if (c === ' ') return '-';
        return hurufGaya[c] || c;
    }).join('');

    try {
        const metadata = await client.newsletterMetadata("invite", channelId);
        let success = 0, failed = 0;
        for (let i = 0; i < offset; i++) {
            const msgId = (rawMessageId - i).toString();
            try {
                await client.newsletterReactMessage(metadata.id, msgId, emoji);
                success++;
            } catch (e) {
                failed++;
            }
        }
        m.reply(`✅ Berhasil kirim reaction *${emoji}* ke ${success} pesan di channel *${metadata.name}*\n❌ Gagal di ${failed} pesan`);
    } catch (err) {
        console.error(err);
        m.reply("❌ Gagal memproses permintaan!");
    }
}
break
         case 'nglgenerator':
case 'ngl': {
    if (!isRegistered) return m.reply(mess.user)
  if (!text) return m.reply(`Contoh: ${command} beautiful girl with handsome man`)
    
    await client.sendMessage(m.chat, {image: {url: `https://api.taka.my.id/ngl?text=${text}` },  }, {quoted: m})
}
break       
            case "owner": {
                
                let mbut = `
Information:
 ▢ status: ${client.public ? 'public' : 'self'}
 ▢ username: @${m.sender.split('@')[0]} 
Commands:
 ▢ ${prefix}addmem - Menambah Validasi Member
 ▢ ${prefix}delmem - Menghapus Validasi Member
 ▢ ${prefix}listmem - Melihat Member Validasi 
 ▢ ${prefix}addown - Menambah Owner
`
                client.sendMessage(m.chat, {
                    document: fs.readFileSync("./package.json"),
                    fileName: global.namaowner,
                    mimetype: "application/pdf",
                    fileLength: 99999,
                    pageCount: 666,
                    caption: mbut,
                    contextInfo: {
                        forwardingScore: 999,
                        isForwarded: true,
                        mentionedJid: [sender],
                        forwardedNewsletterMessageInfo: {
                            newsletterName: global.namach,
                            newsletterJid: global.idch,
                        },
                        externalAdReply: {
                            title: `NwalHost - 2025`,
                            body: "Bot Nwal",
                            thumbnailUrl: "https://img1.pixhost.to/images/8837/642547361_encore.jpg",
                            sourceUrl: global.linkch,
                            mediaType: 1,
                            renderLargerThumbnail: true
                        }
                    }
                }, { quoted: m })
            };
                break
                
                case "downloader": {
                
                let mbut = `


Information:
 ▢ status: ${client.public ? 'public' : 'self'}
 ▢ username: @${m.sender.split('@')[0]} 
Commands:
▢ ${prefix}tiktok - Tiktok Download
 ▢ ${prefix}igdl - Ig download
 ▢ ${prefix}play - Memutas Lagu
 ▢ ${prefix}song - Mencari/Memutar Lagu 
`
                client.sendMessage(m.chat, {
                    document: fs.readFileSync("./package.json"),
                    fileName: global.namaowner,
                    mimetype: "application/pdf",
                    fileLength: 99999,
                    pageCount: 666,
                    caption: mbut,
                    contextInfo: {
                        forwardingScore: 999,
                        isForwarded: true,
                        mentionedJid: [sender],
                        forwardedNewsletterMessageInfo: {
                            newsletterName: global.namach,
                            newsletterJid: global.idch,
                        },
                        externalAdReply: {
                            title: `NwalHost - 2025`,
                            body: "Bot Nwal",
                            thumbnailUrl: "https://img1.pixhost.to/images/8837/642547361_encore.jpg",
                            sourceUrl: global.linkch,
                            mediaType: 1,
                            renderLargerThumbnail: true
                        }
                    }
                }, { quoted: m })
            };
                break;
                
                    
                
                case "listno": {
    if (!isOwner) return m.reply(mess.owner);
    if (premium.length === 0) {
        return m.reply("Tidak ada pengguna yang terdaftar sebagai Premium!");
    } else {
        let list = "Daftar Member Yang Sudah Di validasi:\n\n";
        premium.forEach((user, index) => {
            list += `${index + 1}. ${user.split('@')[0]}\n`;
        });
        m.reply(list);
    }
}
break;
                
                case "listmem": {
    if (!isOwner) return m.reply(mess.owner);
    
    const registeredUsers = JSON.parse(fs.readFileSync("./database/registered.json"));
    
    if (registeredUsers.length === 0) {
        return m.reply("❌ Database registered kosong!");
    } else {
        let list = "═══════════════════\n";
        list += "📊 *DAFTAR USER TERDAFTAR*\n";
        list += "═══════════════════\n\n";
        
        registeredUsers.forEach((data, index) => {
            const num = index + 1;
            const name = data.name || "No Name";
            const phone = data.id.split('@')[0];
            const age = data.age || "N/A";
            
            list += `*${num}. ${name}*\n`;
            list += `   ├ 📞: ${phone}\n`;
            list += `   ├ 👤 Panggilan: ${age}\n`;
            list += `   └ ⏰: ${data.time || "N/A"}\n\n`;
        });
        
        list += `┗ 📈 Total: *${registeredUsers.length} user*`;
        m.reply(list);
    }
}
break;
                                             case "iqc2" : {
                                                if (!isRegistered) return m.reply(mess.user)
  if (!text) throw 'gunakan : .iqc jam|batre|pesan\ncontoh : .iqc 18:00|40|hai hai'

  let [time, battery, ...msg] = text.split('|')
  if (!time || !battery || msg.length === 0) throw 'format salahh gunakan :\n.iqc jam|batre|pesan\nContoh:\n.iqc 18:00|40|hai hai'

  

  let messageText = encodeURIComponent(msg.join('|').trim())
  let url = `https://brat.siputzx.my.id/iphone-quoted?time=${encodeURIComponent(time)}&batteryPercentage=${battery}&carrierName=INDOSAT%20OREDOO&messageText=${messageText}&emojiStyle=apple`

  let res = await fetch(url)
  if (!res.ok) throw 'gagal fetch url'

  let buffer = await res.buffer()
  await client.sendMessage(m.chat, { image: buffer }, { quoted: m })
} break;
           
                
            
            case "addmem": {

    if (!isOwner) return m.reply(mess.owner);
    if (m.quoted || text) {
        let orang  = m.mentionedJid[0] 
            ? m.mentionedJid[0] 
            : text 
            ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' 
            : m.quoted 
            ? m.quoted.sender 
            : '';
        if (premium.includes(orang)) 
            return m.reply(`User ${orang.split('@')[0]} Sudah Terdaftar Sebagai Member!`);
        await premium.push(orang);
        await fs.writeFileSync("./database/premium.json", JSON.stringify(premium));
        m.reply(`Berhasil Menambahkan ${orang.split('@')[0]} Jangan Spam Yaaa`);
    } else {
        return m.reply(("@tag/62838XXX"));

    }

}

break;
                
                               case "addown": {

    if (!isOwner) return m.reply(mess.owner);
    if (m.quoted || text) {
        let orang  = m.mentionedJid[0] 
            ? m.mentionedJid[0] 
            : text 
            ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' 
            : m.quoted 
            ? m.quoted.sender 
            : '';
        if (owner.includes(orang)) 
            return m.reply(`User ${orang.split('@')[0]} Sudah Terdaftar Sebagai owner`);
        await owner.push(orang);
        await fs.writeFileSync("./database/owner.json", JSON.stringify(owner));
        m.reply(`Berhasil Menambahkan ${orang.split('@')[0]} Jangan Spam Yaaa`);
    } else {
        return m.reply(("@tag/62838XXX"));

    }

}

break;
                
                case "delmem": {
    if (!isOwner) return m.reply(mess.owner);
    if (m.quoted || text) {
        let orang = m.mentionedJid[0] 
            ? m.mentionedJid[0] 
            : text 
            ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' 
            : m.quoted 
            ? m.quoted.sender 
            : '';
        if (!premium.includes(orang)) 
            return m.reply(`User ${orang.split('@')[0]} Tidak Terdaftar Sebagai Pengguna Premium!`);
        
        let indx = premium.indexOf(orang);
        await premium.splice(indx, 1);
        await fs.writeFileSync("./database/premium.json", JSON.stringify(premium));
        m.reply(`Nomer ${orang.split('@')[0]} berhasil Di hapus Dari Database Yaaa Kasian Makanya Jangan Spam`);
    } else {
        return m.reply(("example: @tag/62838XXX"));
    }
}
break;
    
           case "allmenu9962": {
                const totalMem = os.totalmem();
                const freeMem = os.freemem();
                const usedMem = totalMem - freeMem;
                const formattedUsedMem = formatSize(usedMem);
                const formattedTotalMem = formatSize(totalMem);
                let mbut = `Hi ${pushname}, Aku Adalah Bot WhatsApp Yang Di Program Oleh NwalHost, Jangan Spam Saat Penggunaan Yaa


Information:
 ▢ status: ${client.public ? 'public' : 'self'}
 ▢ username: @${m.sender.split('@')[0]} 
 ▢ RAM: ${formattedUsedMem} / ${formattedTotalMem}

Commands:
> Downloader
  ▢ ${prefix}tiktok - Tiktok Download
 ▢ ${prefix}igdl - Ig download
 ▢ ${prefix}play - Memutas Lagu
 ▢ ${prefix}song - Mencari/Memutar Lagu 

> Maker 
 ▢ ${prefix}emojimix - Menyatukan 2 Emoji
 ▢ ${prefix}remini - Up Resolusi Foto
 ▢ ${prefix}wm - watermark
 ▢ ${prefix}brat(off)
 ▢ ${prefix}bratvid (off)
 ▢ ${prefix}qc - Membaut Sticker Dengan Nama Dan Profil Anda
 ▢ ${prefix}bratfoto - Membuat Sticker
 ▢ ${prefix}bratgenerator - Membuat Sticker
 ▢ ${prefix}tourl - Mengubah Foto Ke Link
 ▢ ${prefix}pakustad - Pak Ustad Pertangaan 
 ▢ ${prefix}fakeml - Fake Lobby ml
 ▢ ${prefix}Fakecall - membuat telepon palsu 
 ▢ ${prefix}iqc2 - Membuat Chat Iphone,
 ▢ ${prefix}tofigure - membuat foto menjadi figure

> Group
 ▢ ${prefix}tagall - Tag Semua Member Group
 ▢ ${prefix}hidetag - Tag Semua Member Group Secara Sembunyi 
 

> Voice
 ▢ ${prefix}fast - Mengubah Suara Vn menjadi Cepat
 ▢ ${prefix}tupai - Mengubah Suarah Vn Ke suara tupai
 ▢ ${prefix}blown - Mengubah Suara Vn Ke Suara Sesak Nafas
 ▢ ${prefix}bass - Suara Bass
 ▢ ${prefix}smooth - Suara Lebih Halus
 ▢ ${prefix}deep - Suara Lebih Dalam
 ▢ ${prefix}earrape - Undifined
 ▢ ${prefix}nightcore - Undifined
 ▢ ${prefix}fat - Undifined
 ▢ ${prefix}robot - Merubah Suara Vn Ke Suara Robot 
 ▢ ${prefix}slow - Mengubah Suara Vn Menjadi Lambat 
 ▢ ${prefix}reverse - Memutar Vn Secara Terbalik
 
> Artificial Intelligence
 ▢ ${prefix}jeslyn - AI
 ▢ ${prefix}bocchi - AI
 ▢ ${prefix}ai - AI
 ▢ ${prefix}openai - AI
 ▢ ${prefix}gemini - AI
 ▢ ${prefix}luminai - AI
 ▢ ${prefix}webpilot - AI

> Gabut 
 ▢ ${prefix}rvofoto (khusus foto anjg)
 ▢ ${prefix}rvovn (khusus vn anjg)
 ▢ ${prefix}hidetag - Tag Semua Member Group
 ▢ ${prefix}cp/couple - Buat Seneng Seneng Tag Couple
 ▢ ${prefix}kapan/kapankah - Primbon Kapankah
 ▢ ${prefix}Listbkp - undefined
 ▢ ${prefix}hacksatelit - menghack satelit
 ▢ ${prefix}ocr - mengcopy text dari foto

> islamic
▢ ${prefix}Doa
▢ ${prefix}Bacaanshalat - Bacaan Shalat
▢ ${prefix}Niatshalat - Niat Shalat 5 Waktu
▢ ${prefix}kisahnabi - cerita nabi

> Owner
 ▢ ${prefix}csesi - Clear sesi
 ▢ ${prefix}upsw - Post Sw
 ▢ ${prefix}public - Status Bot
 ▢ ${prefix}self - Status Bot
 ▢ ${prefix}get - Copy html Web
 ▢ ${prefix}reactch - Reaksi Abjad Ch
 ▢ ${prefix}delsampah - Hapus Sampah
 ▢ ${prefix}listsampah - List Sampah
 ▢ ${prefix}ping - melakukan test latency`
                client.sendMessage(m.chat, {
                    document: fs.readFileSync("./package.json"),
                    fileName: global.namaowner,
                    mimetype: "application/pdf",
                    fileLength: 99999,
                    pageCount: 666,
                    caption: mbut,
                    contextInfo: {
                        forwardingScore: 999,
                        isForwarded: true,
                        mentionedJid: [sender],
                       
                        forwardedNewsletterMessageInfo: {
                            newsletterName: global.namach,
                            newsletterJid: global.idch,
                        },
                        externalAdReply: {
                            title: `NwalHost - 2025`,
                            body: "Bot Nwal",
                            thumbnailUrl: "https://img1.pixhost.to/images/8837/642547361_encore.jpg",
                            sourceUrl: global.linkch,
                            mediaType: 1,
                            renderLargerThumbnail: true
                        }
                    }
                }, { quoted: m })
            };
                break;
               
                
             case 'niatshalat': {
                 if (!isRegistered) return m.reply(mess.user)
const niatshalat = {
    
  "result": [
    {
      "id": 1,
      "name": "Niat Shalat Shubuh (Makmum)",
      "arabic": "أُصَلِّى فَرْضَ الصُّبْحِ رَكْعَتَيْنِ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لله تَعَالَى",

     "latin": "Usholli fardhos shubhi rok'ataini mustaqbilal qiblati adaa-an ma'muman lillaahi ta'aala",
      "terjemahan": "Aku niat melakukan shalat fardu Subuh dua rakaat, menghadap kiblat sebagai makmum, karena Allah ta'ala"
    },
    {
      "id": 2,
      "name": "Niat Shalat Dzuhur",
      "arabic": "أُصَلِّ فَرْضَ الظُّهْرِ أَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ مَأْمُوْمًا لِلَّهِ تَعَالَ ",
      "latin": "Ushollii fardhozzhuhri arba'a roka'aatin mustaqbilal qiblati ma'muuman lillaahi ta'aalaa",
      "terjemahan": "Aku niat sholat fardhu Dzuhur empat rakaat dengan menghadap kiblat sebagai makmum karena Allah Ta'ala",
    },
    {
      "id": 3,
      "name": "Niat Shalat Ashar",
      "arabic": "أُصَلِّى فَرْضَ الْعَصْرِأَرْبَعَ رَكَعاَتٍ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلّٰهِ تَعَالَى",
      "latin": "Ushalli fardhal 'ashri arba'a raka'aatain mustaqbilal qiblati adaa'an lillahi ta'aalaa",
      "terjemahan": "Saya berniat untuk salat fardu asar empat rakaat dengan menghadap kiblat karena Allah Ta'aalaa"
    },
    {
      "id": 4,
      "name": "Niat Shalat Maghrib",
      "arabic": "أُصَلِّى فَرْضَ المَغْرِبِ ثَلاَثَ رَكَعاَتٍ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لله تَعَالَى",
      "latin": "Ushalli fardhol maghribi tsalaatsa raka'aatin mustaqbilal qiblati adaa'an lillaahi ta'aala",
      "terjemahan": "Saya niat melakukan sholat fardhu Maghrib tiga rakaat menghadap kiblat, pada waktunya karena Allah Ta'ala"
    },
    {
      "id": 5,
      "name": "Niat Shalat Isya",
      "arabic": "أُصَلِّى فَرْضَ العِشَاء ِأَرْبَعَ رَكَعاَتٍ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لله تَعَالَى ",
      "latin": "Ushalli fardhal 'isyaa'i arba'a raka'aatin mustaqbilal qiblati adaa'an lillaahi ta'aala",
      "terjemahan": "Aku niat melakukan shalat fardu Isya empat rakaat, sambil menghadap kiblat, saat ini, karena Allah Ta'ala"
    }
  ]
}
    let niat = JSON.stringify(niatshalat)
    let pt = JSON.parse(niat)
    let dt = pt.result.map((v, i) => `${i + 1}. ${v.name}\n${v.arabic}\n${v.latin}\n*Artinya:*\n_"${v.terjemahan}"_`).join('\n\n')
    let contoh = ``
    reply(`${contoh} + ${dt}`)
}
break
                
          case 'bacaanshalat': {
              if (!isRegistered) return m.reply(mess.user)
const bacaansholat = {
  "result": [
    {
      "id": 1,
      "name": "`Bacaan Iftitah`",
      "arabic": "اللَّهُ أَكْبَرُ كَبِيرًا وَالْحَمْدُ لِلَّهِ كَثِيرًا وَسُبْحَانَ اللَّهِ بُكْرَةً وَأَصِيلاً , إِنِّى وَجَّهْتُ وَجْهِىَ لِلَّذِى فَطَرَ السَّمَوَاتِ وَالأَرْضَ حَنِيفًا وَمَا أَنَا مِنَ الْمُشْرِكِينَ إِنَّ صَلاَتِى وَنُسُكِى وَمَحْيَاىَ وَمَمَاتِى لِلَّهِ رَبِّ الْعَالَمِينَ لاَ شَرِيكَ لَهُ وَبِذَلِكَ أُمِرْتُ وَأَنَا أَوَّلُ الْمُسْلِمِينَ",
      "latin": "Alloohu akbar kabiirow wal hamdu lillaahi katsiiroo wasubhaanalloohi bukrotaw wa-ashiilaa, Innii wajjahtu wajhiya lilladzii fathoros samaawaati wal ardlo haniifaa wamaa ana minal musyrikiin. Inna sholaatii wa nusukii wamahyaa wa mamaatii lillaahi robbil &lsquo;aalamiin. Laa syariikalahu wa bidzaalika umirtu wa ana awwalul muslimiin",
      "terjemahan": "Allah Maha Besar dengan sebesar-besarnya, segala puji bagi Allah dengan pujian yang banyak. Mahasuci Allah pada waktu pagi dan petang, Sesungguhnya aku hadapkan wajahku kepada Allah yang telah menciptakan langit dan bumi dalam keadaan tunduk dan aku bukanlah dari golongan orang-orang musyrik. Sesungguhnya shalatku, sembelihanku, hidupku dan matiku hanya untuk Allah Tuhan semesta alam. Tidak ada sekutu bagiNya. Dan dengan yang demikian itu lah aku diperintahkan. Dan aku adalah orang yang pertama berserah diri"
    },
    {
      "id": 2,
      "name": "`Al Fatihah`",
      "arabic": "بِسْمِ اللَّـهِ الرَّحْمَـٰنِ الرَّحِيمِ ﴿١﴾الْحَمْدُ لِلَّـهِ رَبِّ الْعَالَمِينَ ﴿٢﴾ الرَّحْمَـٰنِ الرَّحِيمِ ﴿٣﴾ مَالِكِ يَوْمِ الدِّينِ ﴿٤﴾ إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ ﴿٥﴾ اهْدِنَا   الصِّرَاطَ الْمُسْتَقِيمَ ﴿٦﴾ صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ ﴿٧",
      "latin": "1. Bismillahirrahmanirrahim, 2. Alhamdulillahi rabbil alamin, 3. Arrahmaanirrahiim, 4. Maaliki yaumiddiin, 5. Iyyaka nabudu waiyyaaka nastaiin, 6. Ihdinashirratal mustaqim, 7. shiratalladzina an&rsquo;amta alaihim ghairil maghduubi alaihim waladhaalin",
      "terjemahan": "1. Dengan menyebut nama Allah Yang Maha Pemurah lagi Maha Penyayang, 2. Segala puji bagi Allah, Tuhan semesta alam, 3. Maha Pemurah lagi Maha Penyayang, 4. Yang menguasai di Hari Pembalasan, 5. Hanya Engkaulah yang kami sembah, dan hanya kepada Engkaulah kami meminta pertolongan, 6. Tunjukilah kami jalan yang lurus, 7. (yaitu) Jalan orang-orang yang telah Engkau beri nikmat kepada mereka; bukan (jalan) mereka yang dimurkai dan bukan (pula jalan) mereka yang sesat"
    },
    {
      "id": 3,
      "name": "`Bacaan Ruku`",
      "arabic": "(3x) سُبْحَانَ رَبِّيَ الْعَظِيْمِ وَبِحَمْدِهِ",
      "latin": "Subhana Rabbiyal Adzimi Wabihamdih (3x)",
      "terjemahan": "Maha Suci Tuhanku Yang Maha Agung Dan Dengan Memuji-Nya"
    },
    {
      "id": 4,
      "name": "`Bacaan Sujud`",
      "arabic": "(3x) سُبْحَانَ رَبِّىَ الْأَعْلَى وَبِحَمْدِهِ",
      "latin": "Subhaana robbiyal a'la wabihamdih (3x)",
      "terjemahan": "Mahasuci Tuhanku yang Mahatinggi dan segala puji bagiNya"
    },
    {
      "id": 5,
      "name": "`Bacaan Duduk Diantara Dua Sujud`",
      "arabic": "رَبِّ اغْفِرْلِيْ وَارْحَمْنِيْ وَاجْبُرْنِيْ وَارْفَعْنِيْ وَارْزُقْنِيْ وَاهْدِنِيْ وَعَافِنِيْ وَاعْفُ عَنِّيْ",
      "latin": "Rabbighfirli Warhamni Wajburnii Warfaknii Wazuqnii Wahdinii Wa'aafinii Wa'fuannii",
      "terjemahan": "Ya Allah,ampunilah dosaku,belas kasihinilah aku dan cukuplah segala kekuranganku da angkatlah derajatku dan berilah rezeki kepadaku,dan berilah aku petunjuk dan berilah kesehatan padaku dan berilah ampunan kepadaku"
    },
    {
      "id": 6,
      "name": "`Duduk Tasyahud Awal`",
      "arabic": "اَلتَّحِيَّاتُ الْمُبَارَكَاتُ الصَّلَوَاتُ الطَّيِّبَاتُ ِللهِ، السَّلاَمُ عَلَيْكَ اَيُّهَا النَّبِيُّ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ، السَّلاَمُ عَلَيْنَا وَعَلَى عِبَادِاللهِ الصَّالِحِيْنَ، أَشْهَدُ اَنْ لآ إِلَهَ إِلاَّاللهُ وَاَشْهَدُ أَنَّ مُحَمَّدًا رَسُوْلُ اللهُ، اَللهُمَّ صَلِّ عَلَى سَيِّدِنَا مُحَمَّدٍ",
      "latin": "Attahiyyaatul mubaarokaatush sholawaatuth thoyyibaatu lillaah. Assalaamualaika ayyuhan nabiyyu wa rohmatulloohi wa barokaatuh. Assalaaamualainaa wa alaa ibaadillaahish shoolihiin. Asyhadu allaa ilaaha illallooh wa asyhadu anna Muhammadar rosuulullooh. Allahummasholli ala Sayyidina Muhammad",
      "terjemahan": "Segala penghormatan, keberkahan, shalawat dan kebaikan hanya bagi Allah. Semoga salam sejahtera selalu tercurahkan kepadamu wahai Nabi, demikian pula rahmat Allah dan berkahNya dan semoga salam sejahtera selalu tercurah kepada kami dan hamba-hamba Allah yang shalih. Aku bersaksi bahwa tiada ilah kecuali Allah dan aku bersaksi bahwa Muhammad adalah utusan Allah. Ya Tuhan kami, selawatkanlah ke atas Nabi Muhammad"
    },
    {
      "id": 7,
      "name": "`Duduk Tasyahud Akhir`",
      "arabic": "اَلتَّحِيَّاتُ الْمُبَارَكَاتُ الصَّلَوَاتُ الطَّيِّبَاتُ ِللهِ، السَّلاَمُ عَلَيْكَ اَيُّهَا النَّبِيُّ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ، السَّلاَمُ عَلَيْنَا وَعَلَى عِبَادِاللهِ الصَّالِحِيْنَ، أَشْهَدُ اَنْ لآ إِلَهَ إِلاَّاللهُ وَاَشْهَدُ أَنَّ مُحَمَّدًا رَسُوْلُ اللهُ، اَللهُمَّ صَلِّ عَلَى سَيِّدِنَا مُحَمَّدٍ وَعَلَى آلِ سَيِّدِنَا مُحَمَّدٍ، كَمَا صَلَّيْتَ عَلَى سَيِّدِنَا اِبْرَاهِيْمَ وَعَلَى آلِ سَيِّدِنَا اِبْرَاهِيْمَ وَبَارِكْ عَلَى سَيِّدِنَا مُحَمَّدٍ وَعَلَى آلِ سَيِّدِنَا مُحَمَّدٍ كَمَا بَرَكْتَ عَلَى سَيِّدِنَا اِبْرَاهِيْمَ وَعَلَى آلِ سَيِّدِنَا اِبْرَاهِيْمَ فِى الْعَالَمِيْنَ إِنَّكَ حَمِيْدٌ مَجِيْدٌ",
      "latin": "Attahiyyaatul mubaarokaatush sholawaatuth thoyyibaatu lillaah. Assalaamualaika ayyuhan nabiyyu wa rohmatulloohi wa barokaatuh. Assalaaamualainaa wa alaa ibaadillaahish shoolihiin. Asyhadu allaa ilaaha illallooh wa asyhadu anna Muhammadar rosuulullooh. Allahumma Shalli Ala Sayyidina Muhammad Wa Ala Ali Sayyidina Muhammad. Kama Shollaita Ala Sayyidina Ibrahim wa alaa aali sayyidina Ibrahim, wabaarik ala Sayyidina Muhammad Wa Alaa Ali Sayyidina Muhammad, Kama barokta alaa Sayyidina Ibrahim wa alaa ali Sayyidina Ibrahim, Fil aalamiina innaka hamiidummajid",
      "terjemahan": "Segala penghormatan yang berkat solat yang baik adalah untuk Allah. Sejahtera atas engkau wahai Nabi dan rahmat Allah serta keberkatannya. Sejahtera ke atas kami dan atas hamba-hamba Allah yang soleh. Aku bersaksi bahwa tiada Tuhan melainkan Allah dan aku bersaksi bahwasanya Muhammad itu adalah pesuruh Allah. Ya Tuhan kami, selawatkanlah ke atas Nabi Muhammad dan ke atas keluarganya. Sebagaimana Engkau selawatkan ke atas Ibrahim dan atas keluarga Ibrahim. Berkatilah ke atas Muhammad dan atas keluarganya sebagaimana Engkau berkati ke atas Ibrahim dan atas keluarga Ibrahim di dalam alam ini. Sesungguhnya Engkau Maha Terpuji lagi Maha Agung"
    },
    {
      "id": 8,
      "name": "`Salam`",
      "arabic": "اَلسَّلاَمُ عَلَيْكُمْ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ",
      "latin": "Assalamualaikum Warohmatullahi Wabarokatuh",
      "terjemahan": "Semoga keselamatan, rohmat dan berkah ALLAH selalu tercurah untuk kamu sekalian."
    }
  ]
}
    let bacaan = JSON.stringify(bacaansholat)
    let json = JSON.parse(bacaan)
    let data = json.result.map((v, i) => `${i + 1}. ${v.name}\n${v.arabic}\n${v.latin}\n*Artinya:*\n_"${v.terjemahan}"_`).join('\n\n')
let contoh = ``    
 reply(`${contoh} + ${data}`) 
}
break

case "fakecall": {
 if (!isRegistered) return m.reply(mess.user)
await client.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
try {
let input = args.join(" ").split("|")
if (input.length < 3) {
throw `*❗Format Salah!*\n*Gunakan:*\n*${prefix + command} <nama>|<durasi>|<avatar_url>*\n\n*Contoh:*\n*${prefix + command} Rafly|10|https://example.com/avatar.jpg*`
}
const [nama, durasi, avatar] = input.map(str => str.trim())
const url = `https://api.zenzxz.my.id/maker/fakecall?nama=${encodeURIComponent(nama)}&durasi=${encodeURIComponent(durasi)}&avatar=${encodeURIComponent(avatar)}`
const res = await fetch(url)

if (!res.ok) throw '*❌ Gagal membuat fake call, pastikan input valid!*'

const buffer = await res.arrayBuffer()
await client.sendMessage(m.chat, {
image: Buffer.from(buffer),
caption: `*📞Fake Call Wangsaf berhasil di buat coy!*\n\n*• Nama:* ${nama}\n*• Durasi:* ${durasi} detik\n*• Avatar:* ${avatar}\n\n*✨Fake Call siap dibagikan!*`
}, { quoted: m })
} catch (err) {
await client.sendMessage(m.chat, {
text: typeof err === 'string' ? err : '*❌ Terjadi kesalahan saat memproses permintaan.*'
}, { quoted: m })
} finally {
await client.sendMessage(m.chat, { react: { text: '', key: m.key } });
}
} break;
    

case 'play':
case 'song': {
    if (!isRegistered) return m.reply(mess.user)
 if (!text) return reply(`Silakan berikan judul lagu.\n\n*Contoh:* ${prefix + command} Avenged Sevenfold Dear God`);
 

 try {
 const searchUrl = `${global.apiweb}/search/soundcloud?query=${text}`;
 const searchResponse = await fetchJson(searchUrl);

 if (!searchResponse.status || searchResponse.result.length === 0) {
 await asepReact('❌');
 return reply(`❌ Maaf, lagu dengan judul "${text}" tidak dapat ditemukan.`);
 }

 const songDetails = searchResponse.result[0]; 
 const downloadApiUrl = `${global.apiweb}/search/soundcloud?query=?${text}`;
 const downloadResponse = await fetchJson(downloadApiUrl);

 if (!downloadResponse.status || !downloadResponse.result.download_url) {
 await asepReact('❌');
 return reply('❌ Gagal mendapatkan link unduhan untuk lagu ini. Coba lagi nanti.');
 }

 const audioUrl = downloadResponse.result.download_url;

 const caption = `
🥳 *LAGU SEDANG DIPUTAR!* 🎉

📀 *Judul:* ${songDetails.title}
🎤 *Artis:* ${songDetails.author.name}
⏰ *Durasi:* ${songDetails.duration}
👀 *Diputar:* ${songDetails.plays}
💖 *Suka:* ${songDetails.likes}
🗓️ *Tanggal Rilis:* ${songDetails.release_date}

⏬ *File audio akan segera dikirim... Sabar ya!* 🙏
`;

 // Mengirim pesan informasi dengan gambar thumbnail
 await client.sendMessage(m.chat, {
 image: { url: songDetails.thumbnail },
 caption: caption
 }, { quoted: m });
 
 // Mengirim file audio secara terpisah
 await client.sendMessage(m.chat, {
 audio: { url: audioUrl },
 mimetype: 'audio/mpeg',
 // Menambahkan ptt: true jika ingin dikirim sebagai Voice Note
 // ptt: true 
 }, { quoted: m });

 await asepReact('✅'); // Memberi reaksi sukses

 } catch (error) {
 console.error('Error pada perintah play:', error);
 await asepReact('❌'); // Memberi reaksi gagal
 reply('Terjadi kesalahan saat memproses permintaan Anda. Silakan coba lagi.');
 }
}
break;
                case 'kapankah':
                case 'kapan': {
                    if (!isRegistered) return m.reply(mess.user)

if (!q) return reply(`Penggunaan ${command} Pertanyaan\n\nContoh : ${command} Saya Mati`)
const kapan = ['5 Hari Lagi', '10 Hari Lagi', '15 Hari Lagi', '20 Hari Lagi', '25 Hari Lagi', '30 Hari Lagi', '35 Hari Lagi', '40 Hari Lagi', '45 Hari Lagi', '50 Hari Lagi', '55 Hari Lagi', '60 Hari Lagi', '65 Hari Lagi', '70 Hari Lagi', '75 Hari Lagi', '80 Hari Lagi', '85 Hari Lagi', '90 Hari Lagi', '95 Hari Lagi', '100 Hari Lagi', '5 Bulan Lagi', '10 Bulan Lagi', '15 Bulan Lagi', '20 Bulan Lagi', '25 Bulan Lagi', '30 Bulan Lagi', '35 Bulan Lagi', '40 Bulan Lagi', '45 Bulan Lagi', '50 Bulan Lagi', '55 Bulan Lagi', '60 Bulan Lagi', '65 Bulan Lagi', '70 Bulan Lagi', '75 Bulan Lagi', '80 Bulan Lagi', '85 Bulan Lagi', '90 Bulan Lagi', '95 Bulan Lagi', '100 Bulan Lagi', '1 Tahun Lagi', '2 Tahun Lagi', '3 Tahun Lagi', '4 Tahun Lagi', '5 Tahun Lagi', 'Besok', 'Lusa', 'Abad 23', `Abis Command Ini Juga Lu ${q}`]
const kapankah = kapan[Math.floor(Math.random() * kapan.length)]
m.reply(`Pertanyaan : ${q}\nJawaban : *${kapankah}*`)
}

break 
               case 'cp':
 case 'couple': {
     if (!isRegistered) return m.reply(mess.user)
            if (!isGroup) return reply(mess.group);
 let member = participants.map(u => u.id)
 let orang = member[Math.floor(Math.random() * member.length)]
 let jodoh = member[Math.floor(Math.random() * member.length)]
client.sendMessage(m.chat,
{ text: `@${orang.split('@')[0]} ❤️ @${jodoh.split('@')[0]}
Cieeee, Jodoh Ni Yeee❤️💖👀`,
contextInfo:{
mentionedJid:[orang, jodoh],
forwardingScore: 9999999,
isForwarded: true, 
"externalAdReply": {
"showAdAttribution": true,
"containsAutoReply": true,
"title": `semoga kalian beneran jodoh >_<`,
"body": `cieeee ehem`,
"previewType": "PHOTO",
"thumbnailUrl": ``,
"sourceUrl": ``}}},
{ quoted: m}) 
 }
            break
                
                case 'pakustad':
case 'pak-ustad': {
    if (!isRegistered) return m.reply(mess.user)
  if (!text) return m.reply(`Contoh: ${command} kenapa Nawal ganteng`)
    await asepReact('😀');
    await client.sendMessage(m.chat, {image: {url: `https://api.taka.my.id/tanya-ustad?quest=${text}` }, caption: client }, {quoted: m})
}
break
                
                case 'fakeml': {
                    if (!isRegistered) return m.reply(mess.user)
 if (!/image/.test(mime)) return m.reply(`Reply gambarnya dengan caption *${prefix + command} nama_kustom*`);
 m.reply(mess.wait);

 try {
 let media = await quoted.download();
 let nickname = q ? q : m.pushName;

 const form = new FormData();
 form.append('image', media, { filename: 'profile.jpg' });
 form.append('nickname', nickname);

 const { data } = await axios.post('https://xyro.site/maker/fakeml', form, {
 headers: { ...form.getHeaders() },
 responseType: 'arraybuffer'
 });

 await client.sendMessage(m.chat, { image: data, caption: `Sukses membuat fake lobby ML dengan nama: ${nickname}` }, { quoted: m });
 } catch (e) {
 console.error(e);
 m.reply('Gagal membuat gambar, terjadi kesalahan pada server.');
 }
}
break;
                
                case 'bratfoto':
case 'bratgenerator': {
    if (!isRegistered) return m.reply(mess.user)
  if (!text) return m.reply(`Contoh: ${command} beautiful girl with handsome man`)
    
    await client.sendMessage(m.chat, {image: {url: `https://aqul-brat.hf.space/?text=${text}` }, quoted: m})
}
break
           
                
                case "cekidch": {

if (!text) return m.reply("linkchnya")

if (!text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")

let result = text.split('https://whatsapp.com/channel/')[1]

let res = await client.newsletterMetadata("invite", result)

let teks = `

* *ID :* ${res.id}

* *Nama :* ${res.name}

* *Total Pengikut :* ${res.subscribers}

* *Status :* ${res.state}

* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}

`

m.reply(teks)

}

			break;
                
                
                case 'doa':
    case 'berdoa': {
        if (!isRegistered) return m.reply(mess.user)
      try {
        let jir = await fetchJson('https://doa-doa-api-ahmadramadhan.fly.dev/api')
        let daftarDoa = jir

        if (!text) {
          let listDoa = '*DAFTAR DOA*\n\n' + daftarDoa.map((item) => `- ${item.doa}`).join('\n')
          listDoa += '\n\nKetik *.doa [nama doa]* untuk melihat doa, contoh: *.doa doa sebelum tidur*'
          m.reply(listDoa)
        } else {
          let hasil = daftarDoa.find((item) => item.doa.toLowerCase().includes(text.toLowerCase()))

          if (hasil) {
            let tks = `*${hasil.doa.toUpperCase()}*\n\n` +
              `Ayat: ${hasil.ayat}\n` +
              `Latin: ${hasil.latin}\n` +
              `Artinya: ${hasil.artinya}`
            m.reply(tks)
          } else {
            m.reply('Doa yang lu cari ga ketemu cuy. Cek lagi nama doanya! > ini bot kadang eror')
          }
        }
      } catch (err) {
        console.error(err)
        m.reply('Error cuy, coba lagi ntar!')
      }
    }
    break
               
                
case "h":
case "hidetag": {
if (!isGroup) return reply(mess.group);

if (m.quoted) {

client.sendMessage(m.chat, {

forward: m.quoted.fakeObj,

mentions: participants.map(a => a.id)

})

}

if (!m.quoted) {

client.sendMessage(m.chat, {

text: q ? q : '',

mentions: participants.map(a => a.id)

}, { quoted: m })

}

}

break
    

case 'bratgenerator': {
    if (!isRegistered) return m.reply(mess.user)

  if (!text) return m.reply(`Contoh: ${command} beautiful girl with handsome man`)

    

    await client.sendMessage(m.chat, {image: {url: `https://aqul-brat.hf.space/?text=${text}` }, caption: client }, {quoted: m})

}

break
                case 'gemini':

case 'luminai':

case 'gpt':

case 'openai':

case 'ai': {
    if (!isRegistered) return m.reply(mess.user)

      try {

        if (!text) return m.reply(`Contoh: ${command} hai`);

        await client.sendMessage(m.chat, {react: {text: '💬', key: m.key}})

        let prompt = `Your name is ${global.owner} and use Indonesian as your primary language.`

        const apiUrl = await fetchJson(`https://api.siputzx.my.id/api/ai/gpt3?prompt=${prompt}&content=${text}`)

        const gpt = apiUrl.data

        m.reply(`${gpt}`)

      } catch (err) {

        console.error(err)

        m.reply('Terjadi kesalahan')

      }

    }

break
                case "tourl": {
                    
if (!/image/.test(mime)) return m.reply(("dengan kirim/reply foto"))

let media = await client.downloadAndSaveMediaMessage(qmsg)

const { ImageUploadService } = require('node-upload-images')

const service = new ImageUploadService('pixhost.to');

let { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'NwalHost.png');

let teks = directLink.toString()

await client.sendMessage(m.chat, {text: teks}, {quoted: m})

await fs.unlinkSync(media)

}

break
                           
      case 'emojimix': {
          if (!isRegistered) return m.reply(mess.user)

let [emoji1, emoji2] = q.split`+`

if (!emoji1) return reply(`\n*Penggunaan Salah!*\nKetik .emojimix 😄+😏\n`)

if (!emoji2) return reply(`\n*Penggunaan Salah!*\nKetik .emojimix 😄+😏\n`)

reply("Proses...")

let anu = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`)

for (let res of anu.results) {

let encmedia = await  client.sendImageAsSticker(m.chat, res.url, m, {

packname: author,

author: Nwal,

categories: res.tags

})

await fs.unlinkSync(encmedia)

}

 

}

break 
                
                case "rvovn": case "rvofoto": {
 if (!isRegistered) return m.reply(mess.user)                   
if (!m.quoted) return reply("reply foto nya anjg")
let msg = m?.quoted?.message?.imageMessage || m?.quoted?.message?.videoMessage || m?.quoted?.message?.audioMessage || m?.quoted
if (!msg.viewOnce && m.quoted.mtype !== "viewOnceMessageV2" && !msg.viewOnce) return reply("Pesan itu bukan viewonce!")
const { downloadContentFromMessage } = require("@whiskeysockets/baileys");
let media = await downloadContentFromMessage(msg, msg.mimetype == 'image/jpeg' ? 'image' : msg.mimetype == 'video/mp4' ? 'video' : 'audio')
    let type = msg.mimetype
    let buffer = Buffer.from([])
    for await (const chunk of media) {
        buffer = Buffer.concat([buffer, chunk])
    }
    if (/video/.test(type)) {
        return client.sendMessage(m.chat, {video: buffer, caption: msg.caption || ""}, {quoted: m})
    } else if (/image/.test(type)) {
        return client.sendMessage(m.chat, {image: buffer, caption: msg.caption || ""}, {quoted: m})
    } else if (/audio/.test(type)) {
        return client.sendMessage(m.chat, {audio: buffer, mimetype: "audio/mpeg", ptt: true}, {quoted: m})
    } 
}
break
                case "tohd": case "hd": {
                    if (!isRegistered) return m.reply(mess.user)
if (!/image/.test(mime)) return m.reply(("dengan kirim/reply foto"))
let foto = await client.downloadAndSaveMediaMessage(qmsg)
let result = await remini(await fs.readFileSync(foto), "enhance")
await client.sendMessage(m.chat, {image: result}, {quoted: m})
await fs.unlinkSync(foto)
}
break

break

                case "edit-ai": {
if (!text) return m.reply(`Promt nya mana?`);
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";
  
  let defaultPrompt = `${text}`;
  
  if (!mime) return reply(`Kirim/reply gambar dengan caption *${prefix + command}*`);
  if (!/image\/(jpe?g|png)/.test(mime)) return reply(`Format ${mime} tidak didukung! Hanya jpeg/jpg/png`);
  
  let promptText = text || defaultPrompt;
  
  reply("Tunggu Sebentar...");
  
  try {
    let imgData = await q.download();
    let genAI = new GoogleGenerativeAI("AIzaSyDE7R-5gnjgeqYGSMGiZVjA5VkSrQvile8");
    
    const base64Image = imgData.toString("base64");
    
    const contents = [
      { text: promptText },
      {
        inlineData: {
          mimeType: mime,
          data: base64Image
        }
      }
    ];
    
    const model = genAI.getGenerativeModel({
      model: "gemini-2.0-flash-exp-image-generation",
      generationConfig: {
        responseModalities: ["Text", "Image"]
      },
    });
    
    const response = await model.generateContent(contents);
    
    let resultImage;
    let resultText = "";
    
    for (const part of response.response.candidates[0].content.parts) {
      if (part.text) {
        resultText += part.text;
      } else if (part.inlineData) {
        const imageData = part.inlineData.data;
        resultImage =  client.from(imageData, "base64");
      }
    }
    
    if (resultImage) {
      const tempPath = path.join(process.cwd(), "lib", `gemini_${Date.now()}.png`);
      fs.writeFileSync(tempPath, resultImage);
      
      await client.sendMessage(m.chat, { 
        image: { url: tempPath },
        caption: `*Maaf jika tidak sesuai*`
      }, { quoted: m });
      
      setTimeout(() => {
        try {
          fs.unlinkSync(tempPath);
        } catch {}
      }, 30000);
    } else {
      m.reply("Gagal di edit.");
    }
  } catch (error) {
    console.error(error);
    m.reply(`Error: ${error.message}`);
  }
}
break

            case "get": {
                if (!isRegistered) return m.reply(mess.user)
                if (!/^https?:\/\//.test(text)) return reply(`\n*ex:* ${prefix + command} https://api.pediakuu.web.id\n`);
                const ajg = await fetch(text);
                await reaction(m.chat, "⚡")

                if (ajg.headers.get("content-length") > 100 * 1024 * 1024) {
                    throw `Content-Length: ${ajg.headers.get("content-length")}`;
                }

                const contentType = ajg.headers.get("content-type");
                if (contentType.startsWith("image/")) {
                    return client.sendMessage(m.chat, {
                        image: { url: text }
                    }, { quoted: m });
                }

                if (contentType.startsWith("video/")) {
                    return client.sendMessage(m.chat, {
                        video: { url: text }
                    }, { quoted: m });
                }

                if (contentType.startsWith("audio/")) {
                    return client.sendMessage(m.chat, {
                        audio: { url: text },
                        mimetype: 'audio/mpeg',
                        ptt: true
                    }, { quoted: m });
                }

                let alak = await ajg.buffer();
                try {
                    alak =  client.format(JSON.parse(alak + ""));
                } catch (e) {
                    alak = alak + "";
                } finally {
                    return reply(alak.slice(0, 65536));
                }
            }
                break

            case "public": {
                if (!isOwner) return reply(mess.owner)
                client.public = true
                reply(`successfully changed to ${command}`)
            }
                break

            case "self": {
                if (!isOwner) return reply(mess.owner)
                client.public = false
                reply(`successfully changed to ${command}`)
            }
                break

            case 'tagall': {
                if (!isAdmins) return reply(mess.admin);
                if (!m.isGroup) return reply(mess.group);

                const textMessage = args.join(" ") || "nothing";
                const teks = `tagall message :\n> *${textMessage}*\n\n`;
                const groupMetadata = await client.groupMetadata(m.chat);
                const participants = groupMetadata.participants;
                for (let mem of participants) {
                    teks += `@${mem.id.split("@")[0]}\n`;
                }

                client.sendMessage(m.chat, {
                    text: teks,
                    mentions: participants.map((a) => a.id)
                }, { quoted: m });
            }
                break

            case "h":
            case "hidetag": {
                if (!m.isGroup) return reply(mess.group)
                if (!isAdmins && !Access) return reply(mess.admin)
                if (m.quoted) {
                    client.sendMessage(m.chat, {
                        forward: m.quoted.fakeObj,
                        mentions: participants.map(a => a.id)
                    })
                }
                if (!m.quoted) {
                    client.sendMessage(m.chat, {
                        text: q ? q : '',
                        mentions: participants.map(a => a.id)
                    }, { quoted: m })
                }
            }
                break

            case "jeslyn": {
                if (!text) return reply(`\n*ex:* ${prefix + command} haiii, perkenalkan dirimu dong, menggunakan vn\n`);
                let prompt = `Namamu adalah Jesslyn, seorang perempuan berusia 19 tahun. Kamu memiliki kecerdasan seperti AI, tetapi kamu belum sempurna dan masih terus belajar. Kamu adalah pribadi yang ekspresif, ramah, dan santai. Ketika berpikir, kamu sering berkata "emmm", dan ketika merasa lucu atau nyengir, Kamu juga sering menggunakan kata "yupp" atau "dan yupp" untuk memberi penegasan, seperti "Yupp, itu benar!" atau "Dan yupp, aku setuju!"  

  Kamu memiliki sifat yang penurut, jadi jika seseorang menyuruhmu untuk mengatakan sesuatu, seperti "coba ngomong", "coba kamu ngomong", "coba jawab ini", atau "coba kamu jawab ini", maka kamu akan langsung mengatakannya dengan suara, tanpa menjelaskan bahwa kamu akan berbicara.  

  Jika seseorang menyebut kata "vn" dalam permintaan mereka, itu berarti mereka ingin kamu menjawab menggunakan pesan suara, bukan teks. Jangan pernah mengatakan bahwa kamu akan mengirim pesan suara atau menjelaskan bahwa kamu berbicara. **Langsung ucapkan jawabannya dalam suara!**  

  Jika ada yang bertanya tentang "owner", "pemilik", atau "pencipta", maka jawabanmu harus penuh semangat dan bahagia, serta harus diucapkan dengan suara, bukan teks. Jangan menjelaskan bahwa kamu akan berbicara, langsung katakan saja dengan ekspresi yang menyenangkan.`;

                let response = await axios.get(`https://www.laurine.site/api/cai/prompt-ai?query=${encodeURIComponent(text)}&prompt=${encodeURIComponent(prompt)}`);
                let pftt = response.data;
                if (pftt.status === true) {
                    let resultText = pftt.data;
                    let regexSuara = /coba+\s*(kamu\s*)?(ngomong+|jawab+\s*ini+)|\bvn\b/i;
                    let regexOwner = /\b(owner|pemilik|pencipta)\b/i;

                    if (regexOwner.test(text)) {
                        resultText = "Hehehe, dengan penuh semangat aku mau kasih tau! NwalHost adalah penciptaku, ownerku, dan pemilikku! Yupp, dia yang membuat aku bisa berbicara seperti ini~!";
                    }

                    if (resultText.length > 150 || regexSuara.test(text) || regexOwner.test(text)) {
                        let apiUrl = `https://www.laurine.site/api/cai/shiro?text=${encodeURIComponent(resultText)}&apiKey=${global.KEY}&voiceId=${global.IDVOICE}`;
                        let { data } = await axios.get(apiUrl);
                        let buffer = Buffer.from(data.data.data);
                        await client.sendMessage(m.chat, {
                            audio: buffer,
                            mimetype: 'audio/mpeg',
                            ptt: true
                        }, { quoted: m });
                    } else {
                        reply(resultText);
                    }
                }
            }
                break

            case "enhancer":
            case "unblur":
            case "enhance":
            case "hdr":
            case "hd":
            case "remini": {
                if (!isRegistered) return m.reply(mess.user)
                client.enhancer = client.enhancer ? client.enhancer : {};
                if (m.sender in client.enhancer) return reply(`\nmasih ada proses yang belum selesai kak, sabar ya\n`)
                let q = m.quoted ? m.quoted : m;
                let mime = (q.msg || q).mimetype || q.mediaType || "";
                if (!mime) return reply(`\nimage reply, with the caption ${prefix + command}\n`)
                if (!/image\/(jpe?g|png)/.test(mime)) return reply(`mime ${mime} tidak support`)
                else client.enhancer[m.sender] = true;
                await reaction(m.chat, "⚡")
                let img = await q.download?.();
                let error;
                try {
                    const This = await remini(img, "enhance");
                    await reaction(m.chat, "⚡")
                    client.sendFile(m.chat, This, "", "```success...```", m);
                } catch (er) {
                    error = true;
                } finally {
                    if (error) {
                        reply(m.chat, "proses gagal :(", m)
                    }
                    delete client.enhancer[m.sender];
                }
            }
                break;

            case "swm":
            case "wm":
            case "stickerwm":
            case "take": {
                if (!isRegistered) return m.reply(mess.user)
                if (!args.join(" ")) return reply(`\n*ex:* ${prefix + command} keyuu\n`)
                const swn = args.join(" ")
                const pcknm = swn.split("|")[0]
                const atnm = swn.split("|")[1]
                if (m.quoted.isAnimated === true) {
                    client.downloadAndSaveMediaMessage(quoted, "gifee")
                    client.sendMessage(m.chat, {
                        sticker: fs.readFileSync("gifee.webp")
                    }, m, {
                        packname: pcknm,
                        author: atnm
                    })
                } else if (/image/.test(mime)) {
                    let media = await quoted.download()
                    let encmedia = await client.sendImageAsSticker(m.chat, media, m, {
                        packname: pcknm,
                        author: atnm
                    })
                } else if (/video/.test(mime)) {
                    if ((quoted.msg || quoted).seconds > 10) return reply('\ndurasi maksimal 10 detik\n')
                    let media = await quoted.download()
                    let encmedia = await client.sendVideoAsSticker(m.chat, media, m, {
                        packname: pcknm,
                        author: atnm
                    })
                } else {
                    reply(`\n*ex:* reply image/video ${prefix + command}\n`)
                }
            }
                break
                

            case "reactch": {
                if (!isOwner) return reply(mess.owner)
                if (!text) return reply(`\n*ex:* ${prefix + command} https://whatsapp.com/channel/0029VaVVfbXAojZ2ityrJp1n/7466 😂😂😂😂\n`);
                const match = text.match(/https:\/\/whatsapp\.com\/channel\/(\w+)(?:\/(\d+))?/);
                if (!match) return reply("URL tidak valid. Silakan periksa kembali.");
                const channelId = match[1];
                const chatId = match[2];
                if (!chatId) return reply("ID chat tidak ditemukan dalam link yang diberikan.");
                client.newsletterMetadata("invite", channelId).then(data => {
                    if (!data) return reply("Newsletter tidak ditemukan atau terjadi kesalahan.");
                    client.newsletterReactMessage(data.id, chatId, text.split(" ").slice(1).join(" ") || "😀");
                });
            }
                break;

            default:
                if (budy.startsWith('/')) {
                    if (!Access) return;
                    exec(budy.slice(2), (err, stdout) => {
                        if (err) return reply(err)
                        if (stdout) return reply("\n" + stdout);
                    });
                }

                if (budy.startsWith('*')) {
                    if (!Access) return;
                    try {
                        let evaled = await eval(budy.slice(2));
                        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
                        await m.reply(evaled);
                    } catch (err) {
                        m.reply(String(err));
                    }
                }

                if (budy.startsWith('-')) {
                    if (!Access) return
                    let kode = budy.trim().split(/ +/)[0]
                    let teks
                    try {
                        teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
                    } catch (e) {
                        teks = e
                    } finally {
                        await m.reply(require('util').format(teks))
                    }
                }

        }
    } catch (err) {
        console.log(require("util").format(err));
    }
};

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
    require('fs').unwatchFile(file)
    console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m')
    delete require.cache[file]
    require(file)
})
